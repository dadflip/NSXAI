#!/bin/sh
# ============================================================
# Charge tous les fichiers .owl du dossier /ontologies
# dans Fuseki au démarrage (un named graph par fichier)
# ============================================================

echo "⏳ Waiting for Fuseki to be ready..."
until curl -sf "$FUSEKI_URL/\$/ping" > /dev/null; do
  sleep 2
done
echo "✅ Fuseki is ready"

# Ensure GaTO dataset exists by creating it if needed
echo "📁 Checking/creating GaTO dataset..."
curl -s -X POST \
  -u "$FUSEKI_USER:$FUSEKI_PASSWORD" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "dbName=GaTO&dbType=tdb2" \
  "$FUSEKI_URL/\$/datasets" > /dev/null 2>&1

echo "📥 Loading ontologies..."

if [ ! -d "/ontologies" ]; then
  echo "❌ /ontologies directory not found!"
  exit 1
fi

ONTOLOGY_COUNT=$(find /ontologies -maxdepth 1 -name "*.owl" -type f | wc -l)
if [ "$ONTOLOGY_COUNT" = "0" ]; then
  echo "⚠️  No .owl files found in /ontologies"
  ls -la /ontologies/ || echo "Cannot list /ontologies"
  exit 1
fi

for OWL_FILE in /ontologies/*.owl; do
  if [ ! -f "$OWL_FILE" ]; then
    continue
  fi
  
  FILENAME=$(basename "$OWL_FILE")
  GRAPHNAME="http://surveys.nees.com.br/ontologies/$FILENAME"

  echo "  📥 Loading $FILENAME..."
  
  # Use cat + pipe instead of --data-binary @file for Alpine compatibility
  HTTP_CODE=$(cat "$OWL_FILE" | curl -s -o /tmp/response.txt -w "%{http_code}" \
    -X PUT \
    -u "$FUSEKI_USER:$FUSEKI_PASSWORD" \
    -H "Content-Type: application/rdf+xml" \
    --data-binary @- \
    "$FUSEKI_URL/GaTO/data?graph=$GRAPHNAME")

  if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "201" ]; then
    echo "    ✅ Loaded (HTTP $HTTP_CODE)"
  else
    echo "    ⚠️  Failed (HTTP $HTTP_CODE)"
    if [ -f /tmp/response.txt ]; then
      echo "    Response: $(cat /tmp/response.txt | head -c 200)"
    fi
  fi
done

echo "🎉 Ontology loading complete!"