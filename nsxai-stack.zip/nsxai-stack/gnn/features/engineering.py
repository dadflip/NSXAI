"""
Feature Engineering for GNN - Generate node and edge features
"""

import logging
from typing import Dict, List, Any, Tuple
import numpy as np
from pathlib import Path
import networkx as nx
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import pickle

try:
    from sentence_transformers import SentenceTransformer
except ImportError:
    SentenceTransformer = None

logger = logging.getLogger(__name__)


class TextEmbeddingGenerator:
    """Generate text embeddings for node labels and descriptions"""
    
    def __init__(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        """Initialize text embedding model"""
        if SentenceTransformer is None:
            logger.warning("sentence-transformers not installed, skipping text embeddings")
            self.model = None
        else:
            try:
                self.model = SentenceTransformer(model_name)
                self.embedding_dim = self.model.get_sentence_embedding_dimension()
                logger.info(f"Loaded embedding model: {model_name}, dim={self.embedding_dim}")
            except Exception as e:
                logger.error(f"Failed to load embedding model: {e}")
                self.model = None
    
    def embed_label(self, label: str) -> np.ndarray:
        """Generate embedding for label"""
        if self.model is None:
            return np.zeros(384)
        try:
            return self.model.encode(label, convert_to_numpy=True)
        except:
            return np.zeros(384)
    
    def embed_description(self, description: str) -> np.ndarray:
        """Generate embedding for description"""
        if self.model is None:
            return np.zeros(384)
        try:
            return self.model.encode(description, convert_to_numpy=True)
        except:
            return np.zeros(384)


class StructuralFeatureGenerator:
    """Generate structural features from graph topology"""
    
    def __init__(self, graph: nx.DiGraph):
        self.graph = graph
        self.scaler = StandardScaler()
    
    def compute_degree_centrality(self) -> Dict[str, float]:
        """Compute degree centrality for all nodes"""
        return nx.degree_centrality(self.graph)
    
    def compute_betweenness_centrality(self) -> Dict[str, float]:
        """Compute betweenness centrality"""
        try:
            return nx.betweenness_centrality(self.graph)
        except:
            return {node: 0.0 for node in self.graph.nodes()}
    
    def compute_eigenvector_centrality(self) -> Dict[str, float]:
        """Compute eigenvector centrality"""
        try:
            return nx.eigenvector_centrality(self.graph, max_iter=100)
        except:
            return {node: 0.0 for node in self.graph.nodes()}
    
    def compute_clustering_coefficient(self) -> Dict[str, float]:
        """Compute local clustering coefficient"""
        undirected = self.graph.to_undirected()
        return nx.clustering(undirected)
    
    def compute_in_out_degrees(self) -> Tuple[Dict[str, int], Dict[str, int]]:
        """Compute in-degree and out-degree for directed graph"""
        in_degree = {node: self.graph.in_degree(node) for node in self.graph.nodes()}
        out_degree = {node: self.graph.out_degree(node) for node in self.graph.nodes()}
        return in_degree, out_degree
    
    def get_structural_features(self) -> Dict[str, Dict[str, float]]:
        """Get all structural features for all nodes"""
        logger.info("Computing structural features...")
        
        degree_cent = self.compute_degree_centrality()
        betweenness_cent = self.compute_betweenness_centrality()
        eigenvector_cent = self.compute_eigenvector_centrality()
        clustering = self.compute_clustering_coefficient()
        in_deg, out_deg = self.compute_in_out_degrees()
        
        features = {}
        for node in self.graph.nodes():
            features[node] = {
                'degree_centrality': degree_cent.get(node, 0.0),
                'betweenness_centrality': betweenness_cent.get(node, 0.0),
                'eigenvector_centrality': eigenvector_cent.get(node, 0.0),
                'clustering_coefficient': clustering.get(node, 0.0),
                'in_degree': in_deg.get(node, 0),
                'out_degree': out_deg.get(node, 0),
            }
        
        return features


class NodeFeatureEngineer:
    """Generate complete node features"""
    
    def __init__(self, graph: nx.DiGraph, nodes: Dict[str, Any]):
        self.graph = graph
        self.nodes = nodes
        self.text_embedder = TextEmbeddingGenerator()
        self.structural_gen = StructuralFeatureGenerator(graph)
        self.node_features = {}
    
    def engineer_features(self) -> Dict[str, np.ndarray]:
        """Generate all node features"""
        logger.info("Engineering node features...")
        
        # Get structural features
        structural_features = self.structural_gen.get_structural_features()
        
        # Combine all features
        for node_iri in self.graph.nodes():
            features_list = []
            
            # Text embeddings
            node_data = self.nodes.get(node_iri)
            if node_data:
                label_emb = self.text_embedder.embed_label(node_data.label)
                desc_emb = self.text_embedder.embed_description(node_data.description)
                features_list.extend([label_emb, desc_emb])
            else:
                features_list.extend([np.zeros(384), np.zeros(384)])
            
            # Structural features
            struct_feat = structural_features[node_iri]
            struct_array = np.array([
                struct_feat['degree_centrality'],
                struct_feat['betweenness_centrality'],
                struct_feat['eigenvector_centrality'],
                struct_feat['clustering_coefficient'],
                struct_feat['in_degree'],
                struct_feat['out_degree'],
            ])
            features_list.append(struct_array)
            
            # Node type encoding
            node_type = node_data.node_type if node_data else "unknown"
            type_encoding = self._encode_node_type(node_type)
            features_list.append(type_encoding)
            
            # Concatenate all features
            self.node_features[node_iri] = np.concatenate(features_list)
        
        logger.info(f"Generated features for {len(self.node_features)} nodes")
        return self.node_features
    
    def _encode_node_type(self, node_type: str) -> np.ndarray:
        """One-hot encode node type"""
        type_map = {'class': 0, 'instance': 1, 'property': 2}
        encoding = np.zeros(3)
        if node_type in type_map:
            encoding[type_map[node_type]] = 1.0
        return encoding
    
    def normalize_features(self, method: str = "standardize") -> Dict[str, np.ndarray]:
        """Normalize all node features"""
        logger.info(f"Normalizing features using {method}...")
        
        # Stack all features
        feature_matrix = np.array([self.node_features[node_id] for node_id in sorted(self.node_features.keys())])
        node_ids = sorted(self.node_features.keys())
        
        # Apply normalization
        if method == "standardize":
            scaler = StandardScaler()
            normalized = scaler.fit_transform(feature_matrix)
        elif method == "minmax":
            scaler = MinMaxScaler()
            normalized = scaler.fit_transform(feature_matrix)
        else:
            normalized = feature_matrix
        
        # Convert back to dict
        normalized_features = {}
        for node_id, features in zip(node_ids, normalized):
            normalized_features[node_id] = features
        
        self.node_features = normalized_features
        return normalized_features


class EdgeFeatureEngineer:
    """Generate edge features"""
    
    def __init__(self, graph: nx.DiGraph, edges: List[Dict[str, Any]]):
        self.graph = graph
        self.edges = edges
        self.edge_features = {}
    
    def engineer_features(self) -> Dict[Tuple[str, str], np.ndarray]:
        """Generate edge features"""
        logger.info("Engineering edge features...")
        
        for edge in self.edges:
            source = edge['source']
            target = edge['target']
            
            features = []
            
            # Edge weight
            features.append(float(edge.get('weight', 1.0)))
            
            # Edge type encoding (one-hot)
            edge_type_encoding = self._encode_edge_type(edge['edge_type'])
            features.extend(edge_type_encoding)
            
            # Relationship strength (from attributes)
            strength = edge.get('attributes', {}).get('strength', 0.5)
            features.append(float(strength))
            
            self.edge_features[(source, target)] = np.array(features)
        
        logger.info(f"Generated features for {len(self.edge_features)} edges")
        return self.edge_features
    
    def _encode_edge_type(self, edge_type: str) -> np.ndarray:
        """One-hot encode edge type"""
        type_map = {
            'is_a': 0,
            'related_to': 1,
            'parent_of': 2,
            'taught_by': 3,
            'enrolled_in': 4,
            'depends_on': 5,
            'inferred_relation': 6,
        }
        encoding = np.zeros(len(type_map))
        if edge_type in type_map:
            encoding[type_map[edge_type]] = 1.0
        return encoding


class FeatureStore:
    """Store and manage all features"""
    
    def __init__(self):
        self.node_features = {}
        self.edge_features = {}
        self.metadata = {}
    
    def save(self, output_path: str):
        """Save features to file"""
        data = {
            'node_features': {k: v.tolist() for k, v in self.node_features.items()},
            'edge_features': {str(k): v.tolist() for k, v in self.edge_features.items()},
            'metadata': self.metadata
        }
        with open(output_path, 'wb') as f:
            pickle.dump(data, f)
        logger.info(f"Saved features to {output_path}")
    
    def load(self, input_path: str):
        """Load features from file"""
        with open(input_path, 'rb') as f:
            data = pickle.load(f)
        
        self.node_features = {k: np.array(v) for k, v in data['node_features'].items()}
        self.edge_features = {eval(k): np.array(v) for k, v in data['edge_features'].items()}
        self.metadata = data['metadata']
        logger.info(f"Loaded features from {input_path}")
