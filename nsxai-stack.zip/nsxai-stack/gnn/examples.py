"""
Example usage of GNN Integration Pipeline
Shows different ways to use the ontology with ML
"""

import logging
from pathlib import Path
import json
from typing import Dict, Any

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def example_1_before_inference():
    """
    EXAMPLE 1: BEFORE INFERENCE
    Use graph features to augment input before neural network
    
    Best for:
    - Feature enrichment
    - Pre-processing
    - Similarity search
    """
    logger.info("\n" + "=" * 80)
    logger.info("EXAMPLE 1: BEFORE INFERENCE - Input Augmentation")
    logger.info("=" * 80)
    
    from gnn import GNNIntegrationPipeline
    
    pipeline = GNNIntegrationPipeline(
        ontology_path="/ontologies/gato.owl",
        rules_path="/app/config/rules.yaml",
        output_dir="/output/example1_before"
    )
    
    # Run with BEFORE mode
    results = pipeline.run_full_pipeline(ml_mode="before")
    
    logger.info("\nResults:")
    logger.info(f"- Knowledge Graph: {results['knowledge_graph']}")
    logger.info(f"- Augmented Features Shape: {results['features']}")
    logger.info(f"- Output Directory: {results['output_directory']}")
    
    # The augmented features can now be used with any ML model
    # e.g., sklearn RandomForest, XGBoost, SVM, etc.
    
    return results


def example_2_during_inference():
    """
    EXAMPLE 2: DURING INFERENCE
    Use GNN (Graph Neural Network) for end-to-end reasoning
    
    Best for:
    - Node classification
    - Link prediction
    - Knowledge graph completion
    - Semantic reasoning
    """
    logger.info("\n" + "=" * 80)
    logger.info("EXAMPLE 2: DURING INFERENCE - GNN End-to-End")
    logger.info("=" * 80)
    
    from gnn import GNNIntegrationPipeline
    
    pipeline = GNNIntegrationPipeline(
        ontology_path="/ontologies/gato.owl",
        rules_path="/app/config/rules.yaml",
        output_dir="/output/example2_during"
    )
    
    # Run with DURING mode (GNN)
    results = pipeline.run_full_pipeline(ml_mode="during")
    
    logger.info("\nResults:")
    logger.info(f"- Knowledge Graph: {results['knowledge_graph']}")
    logger.info(f"- Node Embeddings Dim: {results['features']['num_node_features']}")
    logger.info(f"- GNN Formats Available: {list(results['gnn_transformations'].keys())}")
    
    # Can now use PyTorch Geometric or DGL models with the generated graphs
    
    return results


def example_3_after_inference():
    """
    EXAMPLE 3: AFTER INFERENCE
    Use ontology to validate and correct neural predictions
    
    Best for:
    - Consistency checking
    - Constraint satisfaction
    - Explainability
    - Post-processing validation
    """
    logger.info("\n" + "=" * 80)
    logger.info("EXAMPLE 3: AFTER INFERENCE - Symbolic Validation")
    logger.info("=" * 80)
    
    from gnn import GNNIntegrationPipeline
    
    pipeline = GNNIntegrationPipeline(
        ontology_path="/ontologies/gato.owl",
        rules_path="/app/config/rules.yaml",
        output_dir="/output/example3_after"
    )
    
    # Run with AFTER mode
    results = pipeline.run_full_pipeline(ml_mode="after")
    
    logger.info("\nResults:")
    logger.info(f"- Knowledge Graph: {results['knowledge_graph']}")
    logger.info(f"- ML Integration: {results['ml_integration']}")
    
    # Predictions are now validated against ontology constraints
    
    return results


def example_4_compare_modes():
    """
    EXAMPLE 4: COMPARE ALL MODES
    Extract once, apply all three modes for comparison
    """
    logger.info("\n" + "=" * 80)
    logger.info("EXAMPLE 4: Compare All ML Modes")
    logger.info("=" * 80)
    
    from gnn import GNNIntegrationPipeline
    
    pipeline = GNNIntegrationPipeline(
        ontology_path="/ontologies/gato.owl",
        rules_path="/app/config/rules.yaml",
        output_dir="/output/example4_all_modes"
    )
    
    # Extract & engineer once
    logger.info("Extracting knowledge graph...")
    pipeline._step_extract_knowledge_graph()
    
    logger.info("Engineering features...")
    pipeline._step_engineer_features()
    
    logger.info("Transforming to GNN formats...")
    pipeline._step_transform_to_gnn()
    
    # Run all modes
    logger.info("Running all ML modes...")
    all_results = pipeline.run_all_ml_modes()
    
    logger.info("\nMode Comparison:")
    for mode, results in all_results.items():
        logger.info(f"\n{mode.upper()} Mode:")
        logger.info(f"  Description: {results['description']}")
        logger.info(f"  Key outputs: {list(results.keys())}")
    
    return all_results


def example_5_custom_rules():
    """
    EXAMPLE 5: USING CUSTOM RULES
    Customize extraction and transformation with rules.yaml
    """
    logger.info("\n" + "=" * 80)
    logger.info("EXAMPLE 5: Custom Extraction Rules")
    logger.info("=" * 80)
    
    # Edit rules.yaml to customize:
    # - Which classes/instances to extract
    # - Which relationships to keep
    # - How to engineer features
    # - Which GNN architectures to recommend
    
    rules_path = Path("/app/config/rules.yaml")
    
    if rules_path.exists():
        with open(rules_path) as f:
            import yaml
            rules = yaml.safe_load(f)
        
        logger.info("Current Rules Configuration:")
        logger.info(f"- Node extraction (classes): {rules['node_extraction']['classes']['enabled']}")
        logger.info(f"- Node extraction (instances): {rules['node_extraction']['instances']['enabled']}")
        logger.info(f"- Edge extraction (subsumption): {rules['edge_extraction']['subsumption']['enabled']}")
        logger.info(f"- Edge extraction (properties): {rules['edge_extraction']['object_properties']['enabled']}")
        logger.info(f"- Min node degree: {rules['data_cleaning']['node_filters']['min_degree']}")
        logger.info(f"- Min edge weight: {rules['data_cleaning']['edge_filters']['min_weight']}")
    
    from gnn import GNNIntegrationPipeline
    
    pipeline = GNNIntegrationPipeline(
        ontology_path="/ontologies/gato.owl",
        rules_path=rules_path,
        output_dir="/output/example5_custom"
    )
    
    results = pipeline.run_full_pipeline(ml_mode="during")
    
    return results


def example_6_api_usage():
    """
    EXAMPLE 6: USING REST API
    Access GNN capabilities via HTTP REST endpoints
    """
    logger.info("\n" + "=" * 80)
    logger.info("EXAMPLE 6: REST API Usage")
    logger.info("=" * 80)
    
    import requests
    
    base_url = "http://localhost:8000"
    
    # Check health
    response = requests.get(f"{base_url}/health")
    logger.info(f"Health: {response.json()}")
    
    # Extract knowledge graph
    response = requests.post(f"{base_url}/gnn/extract")
    logger.info(f"Extraction: {response.json()}")
    
    # Engineer features
    response = requests.post(f"{base_url}/gnn/features")
    logger.info(f"Features: {response.json()}")
    
    # Transform to GNN
    response = requests.post(f"{base_url}/gnn/transform")
    logger.info(f"Transformation: {response.json()}")
    
    # Apply ML integration - DURING mode
    response = requests.post(
        f"{base_url}/gnn/ml-integrate",
        json={"mode": "during"}
    )
    logger.info(f"ML Integration: {response.json()}")
    
    # Get status
    response = requests.get(f"{base_url}/gnn/status")
    logger.info(f"Status: {response.json()}")
    
    # List outputs
    response = requests.get(f"{base_url}/gnn/outputs")
    logger.info(f"Outputs: {response.json()}")


def example_7_mode_selection_guide():
    """
    EXAMPLE 7: GUIDE FOR SELECTING THE RIGHT MODE
    Recommendations based on your use case
    """
    logger.info("\n" + "=" * 80)
    logger.info("EXAMPLE 7: Mode Selection Guide")
    logger.info("=" * 80)
    
    recommendations = {
        "Node Classification": {
            "best_mode": "DURING (GNN)",
            "reason": "GNN directly exploits relational structure for classification",
            "why_not_before": "Loses graph information by flattening to features",
            "why_not_after": "Slower - trains model first then validates"
        },
        "Knowledge Graph Completion": {
            "best_mode": "DURING (GNN)",
            "reason": "GNN excels at link prediction through message passing",
            "why_not_before": "Features alone can't capture relationship patterns",
            "why_not_after": "Overkill for predictions without other constraints"
        },
        "Anomaly Detection": {
            "best_mode": "AFTER (Symbolic)",
            "reason": "Ontology constraints directly identify inconsistencies",
            "why_not_before": "Graph context alone may miss logical errors",
            "why_not_during": "GNN may normalize anomalies"
        },
        "Semantic Search": {
            "best_mode": "BEFORE (Augmentation)",
            "reason": "Graph context + text embeddings maximize semantic similarity",
            "why_not_during": "GNN too complex for simple ranking",
            "why_not_after": "No predictions to validate"
        },
        "Explainability": {
            "best_mode": "AFTER (Symbolic)",
            "reason": "Clear logical justifications from ontology rules",
            "why_not_before": "Feature contributions unclear",
            "why_not_during": "Black-box neural reasoning"
        },
        "Fast Inference": {
            "best_mode": "BEFORE (Augmentation)",
            "reason": "Pre-computed features, lightweight neural network",
            "why_not_during": "GNN message passing is expensive",
            "why_not_after": "Extra validation adds latency"
        }
    }
    
    for use_case, recommendation in recommendations.items():
        logger.info(f"\n{use_case}:")
        for key, value in recommendation.items():
            logger.info(f"  {key}: {value}")


def main():
    """Run all examples"""
    
    examples = [
        ("1", "BEFORE Inference (Input Augmentation)", example_1_before_inference),
        ("2", "DURING Inference (GNN End-to-End)", example_2_during_inference),
        ("3", "AFTER Inference (Symbolic Validation)", example_3_after_inference),
        ("4", "Compare All Modes", example_4_compare_modes),
        ("5", "Custom Rules", example_5_custom_rules),
        ("6", "REST API Usage", example_6_api_usage),
        ("7", "Mode Selection Guide", example_7_mode_selection_guide),
    ]
    
    print("\n" + "=" * 80)
    print("GNN Integration Examples")
    print("=" * 80)
    print("\nAvailable Examples:")
    for num, title, _ in examples:
        print(f"  {num}. {title}")
    
    import sys
    if len(sys.argv) > 1:
        choice = sys.argv[1]
        for num, title, func in examples:
            if num == choice:
                logger.info(f"\nRunning Example {num}: {title}")
                try:
                    func()
                except Exception as e:
                    logger.error(f"Example failed: {e}", exc_info=True)
                return
        print(f"\nInvalid choice: {choice}")
    else:
        print("\nUsage: python examples.py <number>")


if __name__ == '__main__':
    main()
