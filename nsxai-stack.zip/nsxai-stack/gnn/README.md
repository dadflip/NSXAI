# GNN Integration Module for NSXAI Stack

Complete pipeline for converting OWL ontologies to Knowledge Graphs and integrating them with Graph Neural Networks (GNNs).

## Overview

This module provides:

1. **Ontology Parsing & Knowledge Graph Extraction** - Convert OWL ontologies to structured knowledge graphs
2. **Feature Engineering** - Generate node and edge features from graph topology and text
3. **ML Integration Modes** - Three strategies for combining symbolic reasoning with neural networks:
   - **BEFORE**: Augment input features with graph context before neural prediction
   - **DURING**: End-to-end GNN reasoning (GCN, GraphSAGE, GAT)
   - **AFTER**: Validate and correct predictions using symbolic constraints
4. **GNN Format Transformations** - Export to PyTorch Geometric, DGL, NetworkX, and GEXF

## Architecture

```
nsxai-stack/gnn/
├── config/
│   └── rules.yaml              # Extraction & transformation rules
├── ontology_converter/
│   └── extractor.py            # Ontology parsing & KG extraction
├── features/
│   └── engineering.py          # Feature generation & normalization
├── ml_integration/
│   └── modes.py                # Before/During/After modes
├── transformers/
│   └── gnn_transformer.py      # GNN format converters
├── __main__.py                 # Main orchestration pipeline
├── requirements.txt
└── README.md
```

## Installation

```bash
cd nsxai-stack/gnn
pip install -r requirements.txt
```

### Optional Dependencies

For specific GNN frameworks:
```bash
# PyTorch Geometric
pip install torch torch-geometric

# DGL (Deep Graph Library)
pip install dgl dgl-cu11

# Optional: sentence-transformers for text embeddings
pip install sentence-transformers
```

## Usage

### Basic Pipeline Run

```python
from gnn import GNNIntegrationPipeline

pipeline = GNNIntegrationPipeline(
    ontology_path="/path/to/ontology.owl",
    rules_path="/path/to/rules.yaml",
    output_dir="./output"
)

# Run with specific ML mode
results = pipeline.run_full_pipeline(ml_mode="during")

# Or run with all modes
results = pipeline.run_all_ml_modes()
```

### Command-Line Usage

```bash
# Run with DURING mode (recommended for most cases)
python -m gnn --ontology /ontologies/gato.owl --rules ./config/rules.yaml --output ./output --mode during

# Run with BEFORE mode
python -m gnn --ontology /ontologies/gato.owl --rules ./config/rules.yaml --output ./output --mode before

# Run with AFTER mode
python -m gnn --ontology /ontologies/gato.owl --rules ./config/rules.yaml --output ./output --mode after

# Run with ALL modes
python -m gnn --ontology /ontologies/gato.owl --rules ./config/rules.yaml --output ./output --mode all
```

## ML Integration Modes

### MODE 1: BEFORE INFERENCE (Input Augmentation)
**Best for**: Pre-processing, feature enrichment, similarity search

```python
config = MLConfig(mode='before', input_features=X, graph=kg_graph, node_features=nf)
integration = MLIntegrationFactory.create('before', config)
result = integration.process()
# Result: augmented_features suitable for traditional ML models
```

**Process**:
1. Extract local graph context for each node
2. Generate semantic embeddings from graph structure
3. Augment original features with graph information
4. Return enriched features for downstream models

**Output**: Enhanced feature vectors ready for any ML model

### MODE 2: DURING INFERENCE (GNN End-to-End)
**Best for**: Node classification, link prediction, semantic reasoning

```python
config = MLConfig(mode='during', graph=kg_graph, node_features=nf, edge_features=ef)
integration = MLIntegrationFactory.create('during', config)
result = integration.process()
# Result: Node embeddings from GNN message passing
```

**Process**:
1. Build graph structure (adjacency matrix)
2. Initialize node embeddings from features
3. Message passing (3 iterations of aggregation)
4. Generate node classifications
5. Compute attention weights

**Output**: Graph embeddings and node predictions directly from GNN

### MODE 3: AFTER INFERENCE (Symbolic Validation)
**Best for**: Consistency checking, explainability, constraint satisfaction

```python
config = MLConfig(mode='after', graph=kg_graph, reasoning_rules=rules)
integration = MLIntegrationFactory.create('after', config)
result = integration.process()
# Result: Verified predictions with ontology constraints applied
```

**Process**:
1. Check predictions against ontology rules
2. Apply constraint satisfaction corrections
3. Verify consistency
4. Generate explanations

**Output**: Verified predictions with confidence scores and explanations

## Configuration (rules.yaml)

The `config/rules.yaml` file controls:

```yaml
# Node extraction
node_extraction:
  classes:
    enabled: true
    embedding_type: "class_embedding"
  instances:
    enabled: true
    embedding_type: "instance_embedding"

# Edge extraction
edge_extraction:
  subsumption:
    enabled: true
    edge_type: "is_a"
  object_properties:
    enabled: true
    edge_type: "related_to"

# Data cleaning & filtering
data_cleaning:
  node_filters:
    min_degree: 1
    exclude_patterns: ["^http://www.w3.org/.*"]
  edge_filters:
    min_weight: 0.5
    remove_self_loops: true

# Feature engineering
feature_engineering:
  node_features:
    text_features:
      - type: "label_embedding"
        dim: 384
    structural_features:
      - type: "degree_centrality"
      - type: "betweenness_centrality"

# GNN architecture recommendations
gnn_architectures:
  gcn: { layers: 3, hidden_dim: 128 }
  graphsage: { layers: 3, hidden_dim: 128 }
  gat: { layers: 3, heads: 8 }
```

## Output Files

After running the pipeline, outputs are in the specified directory:

```
output/
├── knowledge_graph.json        # Full KG in JSON format
├── knowledge_graph.gexf        # KG in GEXF format (viewable in Gephi)
├── features.pkl                # Serialized node/edge features
├── gnn_formats/
│   ├── graph.pt                # PyTorch Geometric format
│   ├── graph.dgl               # DGL format
│   ├── graph.gpickle           # NetworkX format
│   └── stats.json              # Transformation statistics
├── ml_integration_before.json  # BEFORE mode results
├── ml_integration_during.json  # DURING mode results
├── ml_integration_after.json   # AFTER mode results
└── metadata.json               # Pipeline metadata
```

## Integration with NSXAI Stack

### Docker Compose Integration

```yaml
services:
  gnn:
    build:
      context: ./gnn
      dockerfile: Dockerfile
    environment:
      ONTOLOGY_DIR: /ontologies
      RULES_PATH: /app/config/rules.yaml
      OUTPUT_DIR: /output
      ML_MODE: during
    volumes:
      - ./ontologies:/ontologies:ro
      - ./output:/output
    depends_on:
      - hermit
      - fuseki
```

### REST API Integration

A REST API is available for programmatic access:

```bash
# Extract knowledge graph
curl -X POST http://localhost:8000/gnn/extract \
  -H "Content-Type: application/json" \
  -d '{"ontology_path": "/ontologies/gato.owl"}'

# Transform to GNN
curl -X POST http://localhost:8000/gnn/transform \
  -H "Content-Type: application/json" \
  -d '{"format": "pytorch_geometric"}'

# Apply ML integration
curl -X POST http://localhost:8000/gnn/ml-integrate \
  -H "Content-Type: application/json" \
  -d '{"mode": "during"}'
```

## Examples

### Example 1: Full Pipeline with GNN Output

```python
from gnn import GNNIntegrationPipeline

pipeline = GNNIntegrationPipeline(
    ontology_path="/ontologies/gato.owl",
    rules_path="config/rules.yaml",
    output_dir="./output"
)

# Extract & process
results = pipeline.run_full_pipeline(ml_mode="during")

# Access individual components
print(f"Knowledge Graph: {results['knowledge_graph']}")
print(f"Node Features: {results['features']}")
print(f"GNN Formats: {results['gnn_transformations']}")
```

### Example 2: Compare All Modes

```python
pipeline = GNNIntegrationPipeline(
    ontology_path="/ontologies/gato.owl",
    rules_path="config/rules.yaml",
    output_dir="./output"
)

# Extract & engineer features once
pipeline._step_extract_knowledge_graph()
pipeline._step_engineer_features()
pipeline._step_transform_to_gnn()

# Try all modes
modes_results = pipeline.run_all_ml_modes()

# Compare outputs
for mode, results in modes_results.items():
    print(f"\n{mode.upper()} Mode:")
    print(f"  Output format: {results['description']}")
```

### Example 3: Custom Feature Engineering

```python
from gnn.ontology_converter.extractor import KnowledgeGraphExtractor
from gnn.features.engineering import NodeFeatureEngineer

extractor = KnowledgeGraphExtractor("ontology.owl", "rules.yaml")
nodes, edges, graph = extractor.extract()

engineer = NodeFeatureEngineer(graph, nodes)
node_features = engineer.engineer_features()
node_features = engineer.normalize_features(method="minmax")
```

## Performance Considerations

### Knowledge Graph Size
- Small (< 1K nodes): Process in-memory, all modes available
- Medium (1K - 100K nodes): Use message passing limits, sample edges
- Large (> 100K nodes): Stream processing recommended

### Feature Engineering
- Text embeddings: ~50ms per node (with sentence-transformers)
- Structural features: ~100ms for complete graph
- Total: ~1-2s for typical ontologies

### GNN Transformation
- PyTorch Geometric: ~100ms
- DGL: ~200ms
- Total formats: ~1s

## Troubleshooting

### "No .owl files found"
- Check `ONTOLOGY_DIR` environment variable
- Ensure OWL files have `.owl` extension

### "sentence-transformers not installed"
- Text embeddings will be skipped
- Install with: `pip install sentence-transformers`

### "PyTorch Geometric not installed"
- PyTorch Geometric format will be skipped
- Install with: `pip install torch torch-geometric`

### Memory errors with large ontologies
- Use `sample_edges=True` in extraction config
- Reduce embedding dimension in `rules.yaml`
- Process in batches

## References

- [OWLready2 Documentation](https://pythonhosted.org/Owlready2/)
- [PyTorch Geometric](https://pytorch-geometric.readthedocs.io/)
- [DGL Documentation](https://docs.dgl.ai/)
- [NetworkX](https://networkx.org/)

## License

Same as NSXAI Stack
