"""
Stack Integration Module
Orchestrates the complete pipeline: Ontology → Hermit → Knowledge Graph → GNN

Ensures proper data flow and dependency management between stack modules
"""

import logging
import json
from pathlib import Path
from typing import Dict, Any, Optional, List
import os
from dataclasses import dataclass
import requests

logger = logging.getLogger(__name__)


@dataclass
class StackConfig:
    """Configuration for NSXAI stack integration"""
    ontology_dir: str = os.getenv("ONTOLOGY_DIR", "/ontologies")
    hermit_url: str = os.getenv("HERMIT_URL", "http://hermit:7777")
    fuseki_url: str = os.getenv("FUSEKI_URL", "http://fuseki:3030")
    fuseki_dataset: str = os.getenv("FUSEKI_DATASET", "GaTO")
    rules_path: str = os.getenv("RULES_PATH", "/app/config/rules.yaml")
    output_dir: str = os.getenv("OUTPUT_DIR", "/output")
    lms_api_url: str = os.getenv("LMS_API_URL", "http://lms-api:4000")


class HermitClient:
    """Client for Hermit reasoning service"""
    
    def __init__(self, hermit_url: str):
        self.hermit_url = hermit_url
        self.timeout = 60
    
    def health(self) -> bool:
        """Check if Hermit is available"""
        try:
            response = requests.get(f"{self.hermit_url}/health", timeout=5)
            return response.status_code == 200
        except Exception as e:
            logger.warning(f"Hermit health check failed: {e}")
            return False
    
    def is_consistent(self) -> bool:
        """Check ontology consistency"""
        try:
            response = requests.get(
                f"{self.hermit_url}/consistent",
                timeout=self.timeout
            )
            data = response.json()
            return data.get("consistent", False)
        except Exception as e:
            logger.error(f"Failed to check consistency: {e}")
            return False
    
    def get_all_classes(self) -> List[str]:
        """Get all classes from reasoner"""
        try:
            response = requests.get(
                f"{self.hermit_url}/classes",
                timeout=self.timeout
            )
            data = response.json()
            return data.get("classes", [])
        except Exception as e:
            logger.error(f"Failed to get classes: {e}")
            return []
    
    def get_inferred_subclasses(self, class_iri: str, direct: bool = False) -> List[str]:
        """Get inferred subclasses"""
        try:
            response = requests.get(
                f"{self.hermit_url}/classes/subclasses",
                params={"iri": class_iri, "direct": str(direct).lower()},
                timeout=self.timeout
            )
            data = response.json()
            return data.get("subclasses", [])
        except Exception as e:
            logger.error(f"Failed to get subclasses: {e}")
            return []
    
    def get_inferred_superclasses(self, class_iri: str, direct: bool = False) -> List[str]:
        """Get inferred superclasses"""
        try:
            response = requests.get(
                f"{self.hermit_url}/classes/superclasses",
                params={"iri": class_iri, "direct": str(direct).lower()},
                timeout=self.timeout
            )
            data = response.json()
            return data.get("superclasses", [])
        except Exception as e:
            logger.error(f"Failed to get superclasses: {e}")
            return []
    
    def get_inferred_instances(self, class_iri: str, direct: bool = False) -> List[str]:
        """Get inferred instances of a class"""
        try:
            response = requests.get(
                f"{self.hermit_url}/instances",
                params={"iri": class_iri, "direct": str(direct).lower()},
                timeout=self.timeout
            )
            data = response.json()
            return data.get("instances", [])
        except Exception as e:
            logger.error(f"Failed to get instances: {e}")
            return []
    
    def get_inferred_types(self, instance_iri: str) -> List[str]:
        """Get inferred types of an individual"""
        try:
            response = requests.get(
                f"{self.hermit_url}/individual/types",
                params={"iri": instance_iri},
                timeout=self.timeout
            )
            data = response.json()
            return data.get("inferred_types", [])
        except Exception as e:
            logger.error(f"Failed to get inferred types: {e}")
            return []
    
    def get_individual_properties(self, instance_iri: str) -> Dict[str, List[str]]:
        """Get properties of an individual"""
        try:
            response = requests.get(
                f"{self.hermit_url}/individual/properties",
                params={"iri": instance_iri},
                timeout=self.timeout
            )
            data = response.json()
            return data.get("properties", {})
        except Exception as e:
            logger.error(f"Failed to get properties: {e}")
            return {}
    
    def classify(self) -> Dict[str, Any]:
        """Run classification and return inferences"""
        try:
            response = requests.post(
                f"{self.hermit_url}/classify",
                timeout=self.timeout
            )
            return response.json()
        except Exception as e:
            logger.error(f"Classification failed: {e}")
            return {}
    
    def reload(self) -> bool:
        """Reload ontology in Hermit"""
        try:
            response = requests.post(
                f"{self.hermit_url}/reload",
                timeout=self.timeout
            )
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Reload failed: {e}")
            return False


class FusekiClient:
    """Client for Fuseki triple store"""
    
    def __init__(self, fuseki_url: str, dataset: str):
        self.fuseki_url = fuseki_url
        self.dataset = dataset
        self.timeout = 60
    
    def health(self) -> bool:
        """Check if Fuseki is available"""
        try:
            response = requests.get(f"{self.fuseki_url}/$/ping", timeout=5)
            return response.status_code == 200
        except Exception as e:
            logger.warning(f"Fuseki health check failed: {e}")
            return False
    
    def query_sparql(self, sparql_query: str) -> Dict[str, Any]:
        """Execute SPARQL query"""
        try:
            response = requests.get(
                f"{self.fuseki_url}/{self.dataset}/sparql",
                params={"query": sparql_query},
                timeout=self.timeout
            )
            return response.json()
        except Exception as e:
            logger.error(f"SPARQL query failed: {e}")
            return {}
    
    def load_ttl(self, ttl_content: str, named_graph: str = None) -> bool:
        """Load RDF/TTL data"""
        try:
            headers = {"Content-Type": "text/turtle"}
            url = f"{self.fuseki_url}/{self.dataset}/data"
            
            if named_graph:
                url += f"?graph={named_graph}"
            
            response = requests.post(
                url,
                data=ttl_content.encode('utf-8'),
                headers=headers,
                timeout=self.timeout
            )
            return response.status_code in [200, 201]
        except Exception as e:
            logger.error(f"Failed to load TTL: {e}")
            return False


class StackIntegrationPipeline:
    """
    Complete pipeline orchestration:
    Ontology → Hermit (reasoning) → Knowledge Graph → GNN
    
    This ensures proper data flow between all stack components
    """
    
    def __init__(self, config: Optional[StackConfig] = None):
        self.config = config or StackConfig()
        self.hermit = HermitClient(self.config.hermit_url)
        self.fuseki = FusekiClient(self.config.fuseki_url, self.config.fuseki_dataset)
        
        # Pipeline state
        self.hermit_loaded = False
        self.kg_with_inferences = None
        self.gnn_results = None
    
    def wait_for_services(self, timeout: int = 120) -> bool:
        """Wait for all required services to be ready"""
        logger.info("Waiting for stack services to be ready...")
        import time
        
        start = time.time()
        while time.time() - start < timeout:
            fuseki_ok = self.fuseki.health()
            hermit_ok = self.hermit.health()
            
            if fuseki_ok and hermit_ok:
                logger.info("✓ All services ready")
                return True
            
            logger.info(f"  Fuseki: {'✓' if fuseki_ok else '✗'}")
            logger.info(f"  Hermit: {'✓' if hermit_ok else '✗'}")
            
            time.sleep(5)
        
        logger.error("Services did not become ready in time")
        return False
    
    def step_1_verify_ontology_in_hermit(self) -> bool:
        """Step 1: Verify ontology is loaded in Hermit"""
        logger.info("\n" + "=" * 80)
        logger.info("STEP 1: VERIFY ONTOLOGY IN HERMIT")
        logger.info("=" * 80)
        
        if not self.hermit.health():
            logger.error("Hermit service is not responding")
            return False
        
        # Check consistency
        is_consistent = self.hermit.is_consistent()
        logger.info(f"Ontology consistency: {'✓ Consistent' if is_consistent else '✗ Inconsistent'}")
        
        # Get all classes
        classes = self.hermit.get_all_classes()
        logger.info(f"Total classes: {len(classes)}")
        
        if len(classes) == 0:
            logger.error("No classes found in Hermit - ontology may not be loaded")
            return False
        
        self.hermit_loaded = True
        logger.info("✓ Ontology verified in Hermit")
        return True
    
    def step_2_extract_inferences(self) -> Dict[str, Any]:
        """Step 2: Extract inferred knowledge from Hermit"""
        logger.info("\n" + "=" * 80)
        logger.info("STEP 2: EXTRACT INFERENCES FROM HERMIT")
        logger.info("=" * 80)
        
        if not self.hermit_loaded:
            logger.error("Ontology not verified - run step 1 first")
            return {}
        
        logger.info("Extracting inferred class hierarchy...")
        
        inferences = {
            'classes': {},
            'instances': {},
            'relations': []
        }
        
        # Get all classes with their inferred subclasses and instances
        classes = self.hermit.get_all_classes()
        
        for class_iri in classes[:50]:  # Limit for demo, process all in production
            # Get inferred instances
            instances = self.hermit.get_inferred_instances(class_iri, direct=False)
            
            inferences['classes'][class_iri] = {
                'instances': instances,
                'instance_count': len(instances)
            }
        
        logger.info(f"Extracted inferences for {len(inferences['classes'])} classes")
        logger.info("✓ Inferences extracted")
        
        return inferences
    
    def step_3_create_enriched_kg(self, inferences: Dict[str, Any]) -> Dict[str, Any]:
        """Step 3: Create Knowledge Graph enriched with inferences"""
        logger.info("\n" + "=" * 80)
        logger.info("STEP 3: CREATE ENRICHED KNOWLEDGE GRAPH")
        logger.info("=" * 80)
        
        logger.info("Building KG from asserted + inferred axioms...")
        
        # Use custom extractor that includes Hermit inferences
        from gnn.ontology_converter.extractor_with_hermit import KnowledgeGraphExtractorWithHermit
        
        try:
            extractor = KnowledgeGraphExtractorWithHermit(
                ontology_path=f"{self.config.ontology_dir}/gato.owl",
                rules_path=self.config.rules_path,
                hermit_client=self.hermit  # Pass Hermit client
            )
            
            nodes, edges, graph = extractor.extract()
            stats = extractor.get_statistics()
            
            logger.info(f"Knowledge Graph Statistics:")
            logger.info(f"  Nodes: {stats['num_nodes']}")
            logger.info(f"  Edges: {stats['num_edges']}")
            logger.info(f"  Classes: {stats['num_classes']}")
            logger.info(f"  Instances: {stats['num_instances']}")
            logger.info(f"  Avg Degree: {stats['avg_degree']:.2f}")
            
            self.kg_with_inferences = {
                'nodes': nodes,
                'edges': edges,
                'graph': graph,
                'statistics': stats
            }
            
            logger.info("✓ Enriched KG created")
            return self.kg_with_inferences
            
        except Exception as e:
            logger.error(f"Failed to create KG: {e}")
            return {}
    
    def step_4_transform_to_gnn(self) -> Dict[str, Any]:
        """Step 4: Transform enriched KG to GNN formats"""
        logger.info("\n" + "=" * 80)
        logger.info("STEP 4: TRANSFORM TO GNN FORMATS")
        logger.info("=" * 80)
        
        if not self.kg_with_inferences:
            logger.error("KG not created - run step 3 first")
            return {}
        
        try:
            from gnn.features.engineering import NodeFeatureEngineer, EdgeFeatureEngineer
            from gnn.transformers.gnn_transformer import GNNTransformerPipeline
            
            # Extract features
            logger.info("Engineering features...")
            node_engineer = NodeFeatureEngineer(
                self.kg_with_inferences['graph'],
                self.kg_with_inferences['nodes']
            )
            node_features = node_engineer.engineer_features()
            node_features = node_engineer.normalize_features(method="standardize")
            
            edge_engineer = EdgeFeatureEngineer(
                self.kg_with_inferences['graph'],
                self.kg_with_inferences['edges']
            )
            edge_features = edge_engineer.engineer_features()
            
            logger.info(f"Generated {len(node_features)} node features")
            logger.info(f"Generated {len(edge_features)} edge features")
            
            # Transform to GNN formats
            logger.info("Transforming to GNN formats...")
            transformer = GNNTransformerPipeline(
                self.kg_with_inferences['graph'],
                self.kg_with_inferences['nodes'],
                self.kg_with_inferences['edges'],
                node_features,
                edge_features
            )
            
            transformations = transformer.transform_all()
            logger.info(f"Created {len(transformations)} GNN formats")
            
            logger.info("✓ GNN transformation complete")
            return transformations
            
        except Exception as e:
            logger.error(f"Transformation failed: {e}")
            import traceback
            traceback.print_exc()
            return {}
    
    def step_5_apply_ml_integration(self, mode: str = "during") -> Dict[str, Any]:
        """Step 5: Apply ML integration with specified mode"""
        logger.info("\n" + "=" * 80)
        logger.info(f"STEP 5: ML INTEGRATION - Mode: {mode.upper()}")
        logger.info("=" * 80)
        
        if not self.kg_with_inferences:
            logger.error("KG not created - run step 3 first")
            return {}
        
        try:
            from gnn.ml_integration.modes import MLIntegrationFactory, MLConfig
            
            config = MLConfig(
                mode=mode,
                graph=self.kg_with_inferences['graph'],
                node_features={},  # Would be populated from step 4
                edge_features={}
            )
            
            integration = MLIntegrationFactory.create(mode, config)
            result = integration.process()
            
            logger.info(f"✓ ML Integration '{mode}' complete")
            return result
            
        except Exception as e:
            logger.error(f"ML integration failed: {e}")
            return {}
    
    def run_complete_pipeline(self, ml_mode: str = "during") -> Dict[str, Any]:
        """
        Run complete pipeline from ontology to GNN
        
        Flow: Ontology → Hermit → KG (with inferences) → GNN
        """
        logger.info("\n" + "=" * 80)
        logger.info("NSXAI STACK COMPLETE INTEGRATION PIPELINE")
        logger.info("=" * 80)
        logger.info("Flow: Ontology → Hermit → KG (inferred) → GNN")
        
        # Wait for services
        if not self.wait_for_services():
            return {'error': 'Services not ready'}
        
        # Step 1: Verify ontology in Hermit
        if not self.step_1_verify_ontology_in_hermit():
            return {'error': 'Ontology verification failed'}
        
        # Step 2: Extract inferences
        inferences = self.step_2_extract_inferences()
        
        # Step 3: Create enriched KG
        kg = self.step_3_create_enriched_kg(inferences)
        if not kg:
            return {'error': 'KG creation failed'}
        
        # Step 4: Transform to GNN
        transformations = self.step_4_transform_to_gnn()
        if not transformations:
            return {'error': 'GNN transformation failed'}
        
        # Step 5: Apply ML integration
        ml_results = self.step_5_apply_ml_integration(ml_mode)
        
        logger.info("\n" + "=" * 80)
        logger.info("PIPELINE COMPLETE - All steps successful!")
        logger.info("=" * 80)
        
        return {
            'status': 'success',
            'hermit_ready': self.hermit_loaded,
            'kg_statistics': kg.get('statistics', {}),
            'gnn_formats': list(transformations.keys()),
            'ml_mode': ml_mode,
            'ml_integration': ml_results
        }


def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='NSXAI Stack Integration Pipeline')
    parser.add_argument('--ml-mode', default='during', choices=['before', 'during', 'after'],
                       help='ML integration mode')
    parser.add_argument('--skip-wait', action='store_true', help='Skip service health check')
    
    args = parser.parse_args()
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Run pipeline
    pipeline = StackIntegrationPipeline()
    
    if args.skip_wait:
        pipeline.hermit_loaded = True  # Assume services are ready
    
    results = pipeline.run_complete_pipeline(ml_mode=args.ml_mode)
    
    print("\n" + json.dumps(results, indent=2, default=str))


if __name__ == '__main__':
    main()
