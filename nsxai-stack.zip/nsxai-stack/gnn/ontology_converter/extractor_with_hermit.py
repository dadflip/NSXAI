"""
Knowledge Graph Extractor with Hermit Integration
Extracts KG from asserted ontology + inferred axioms from Hermit
"""

import logging
from typing import Dict, List, Set, Tuple, Any, Optional
from dataclasses import dataclass, field, asdict
import json
import yaml
import networkx as nx

logger = logging.getLogger(__name__)


@dataclass
class Node:
    """Represents a node in the knowledge graph"""
    iri: str
    node_type: str  # class, instance, property
    label: str = ""
    description: str = ""
    is_inferred: bool = False  # True if from Hermit inferences
    attributes: Dict[str, Any] = field(default_factory=dict)
    embedding: List[float] = field(default_factory=list)
    features: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Edge:
    """Represents an edge in the knowledge graph"""
    source: str
    target: str
    edge_type: str
    weight: float = 1.0
    direction: str = "directed"
    is_inferred: bool = False  # True if from Hermit reasoning
    attributes: Dict[str, Any] = field(default_factory=dict)


class KnowledgeGraphExtractorWithHermit:
    """
    Extract knowledge graph incorporating inferred axioms from Hermit
    
    This ensures the KG includes both:
    1. Asserted facts from the ontology
    2. Inferred facts from Hermit reasoning
    """
    
    def __init__(self, ontology_path: str, rules_path: str, hermit_client: Optional[Any] = None):
        """
        Args:
            ontology_path: Path to OWL ontology
            rules_path: Path to extraction rules
            hermit_client: HermitClient instance for fetching inferences
        """
        self.ontology_path = ontology_path
        self.rules_path = rules_path
        self.hermit_client = hermit_client
        
        self.nodes: Dict[str, Node] = {}
        self.edges: List[Edge] = []
        self.graph = nx.DiGraph()
        
        # Load rules
        with open(rules_path, 'r') as f:
            self.rules = yaml.safe_load(f)
    
    def extract(self) -> Tuple[Dict[str, Node], List[Edge], nx.DiGraph]:
        """Extract complete KG with inferences"""
        logger.info("Extracting Knowledge Graph with Hermit Inferences")
        logger.info("=" * 80)
        
        # Step 1: Extract asserted facts
        logger.info("\nStep 1: Extracting asserted facts from ontology...")
        self._extract_asserted_facts()
        logger.info(f"  Extracted {len(self.nodes)} nodes from ontology")
        
        # Step 2: Enrich with Hermit inferences
        if self.hermit_client:
            logger.info("\nStep 2: Enriching with Hermit inferences...")
            self._enrich_with_hermit_inferences()
            logger.info(f"  Enriched with Hermit data")
        
        # Step 3: Apply filtering
        logger.info("\nStep 3: Applying data cleaning filters...")
        self._apply_filters()
        logger.info(f"  After filtering: {len(self.nodes)} nodes, {len(self.edges)} edges")
        
        # Step 4: Build NetworkX graph
        self.build_networkx_graph()
        
        logger.info(f"\n✓ KG extraction complete")
        return self.nodes, self.edges, self.graph
    
    def _extract_asserted_facts(self):
        """Extract facts directly from ontology file"""
        try:
            from owlready2 import get_ontology
            
            ontology = get_ontology(f"file://{self.ontology_path}").load()
            
            # Extract classes
            for cls in ontology.classes():
                class_iri = str(cls.iri)
                label = cls.label[0] if hasattr(cls, 'label') and cls.label else ""
                description = cls.comment[0] if hasattr(cls, 'comment') and cls.comment else ""
                
                node = Node(
                    iri=class_iri,
                    node_type="class",
                    label=str(label),
                    description=str(description),
                    is_inferred=False,
                    attributes={'source': 'asserted'}
                )
                self.nodes[class_iri] = node
            
            # Extract instances
            for ind in ontology.individuals():
                instance_iri = str(ind.iri)
                
                node = Node(
                    iri=instance_iri,
                    node_type="instance",
                    label=instance_iri.split('/')[-1].split('#')[-1],
                    is_inferred=False,
                    attributes={'source': 'asserted'}
                )
                self.nodes[instance_iri] = node
            
            # Extract relationships
            for cls in ontology.classes():
                for subclass in cls.subclasses():
                    sub_iri = str(subclass.iri)
                    super_iri = str(cls.iri)
                    
                    if super_iri != sub_iri:  # Skip self-loops
                        edge = Edge(
                            source=sub_iri,
                            target=super_iri,
                            edge_type="is_a",
                            weight=1.0,
                            is_inferred=False,
                            attributes={'source': 'asserted'}
                        )
                        self.edges.append(edge)
        
        except Exception as e:
            logger.error(f"Failed to extract asserted facts: {e}")
    
    def _enrich_with_hermit_inferences(self):
        """Enrich KG with inferred axioms from Hermit"""
        if not self.hermit_client:
            logger.warning("Hermit client not available, skipping inferences")
            return
        
        try:
            # Get all classes from Hermit
            classes = self.hermit_client.get_all_classes()
            logger.info(f"Processing inferences for {len(classes)} classes...")
            
            inferred_count = 0
            
            for class_iri in classes:
                # Add class if not already present
                if class_iri not in self.nodes:
                    node = Node(
                        iri=class_iri,
                        node_type="class",
                        label=class_iri.split('/')[-1].split('#')[-1],
                        is_inferred=True,
                        attributes={'source': 'hermit_inferred'}
                    )
                    self.nodes[class_iri] = node
                    inferred_count += 1
                
                # Get inferred instances
                instances = self.hermit_client.get_inferred_instances(class_iri, direct=False)
                
                for instance_iri in instances:
                    # Add instance if not present
                    if instance_iri not in self.nodes:
                        node = Node(
                            iri=instance_iri,
                            node_type="instance",
                            label=instance_iri.split('/')[-1].split('#')[-1],
                            is_inferred=True,
                            attributes={'source': 'hermit_inferred'}
                        )
                        self.nodes[instance_iri] = node
                        inferred_count += 1
                    
                    # Add inferred instance-of relationship
                    edge_key = (instance_iri, class_iri, "rdf:type")
                    if not any(e.source == instance_iri and e.target == class_iri and e.edge_type == "rdf:type" for e in self.edges):
                        edge = Edge(
                            source=instance_iri,
                            target=class_iri,
                            edge_type="rdf:type",
                            weight=0.95,  # High confidence for inferred facts
                            is_inferred=True,
                            attributes={'source': 'hermit_inferred', 'confidence': 0.95}
                        )
                        self.edges.append(edge)
                
                # Get inferred subclasses
                subclasses = self.hermit_client.get_inferred_subclasses(class_iri, direct=False)
                
                for sub_iri in subclasses:
                    if sub_iri != class_iri:  # Skip self-references
                        # Add subclass if not present
                        if sub_iri not in self.nodes:
                            node = Node(
                                iri=sub_iri,
                                node_type="class",
                                label=sub_iri.split('/')[-1].split('#')[-1],
                                is_inferred=True,
                                attributes={'source': 'hermit_inferred'}
                            )
                            self.nodes[sub_iri] = node
                            inferred_count += 1
                        
                        # Add inferred is-a relationship
                        if not any(e.source == sub_iri and e.target == class_iri and e.edge_type == "is_a" for e in self.edges):
                            edge = Edge(
                                source=sub_iri,
                                target=class_iri,
                                edge_type="is_a",
                                weight=0.9,  # Slightly lower confidence
                                is_inferred=True,
                                attributes={'source': 'hermit_inferred', 'confidence': 0.9}
                            )
                            self.edges.append(edge)
            
            logger.info(f"Added {inferred_count} inferred nodes and {len(self.edges)} edges")
        
        except Exception as e:
            logger.error(f"Failed to enrich with Hermit inferences: {e}")
    
    def _apply_filters(self):
        """Apply data cleaning filters"""
        filters = self.rules.get('data_cleaning', {})
        
        # Filter nodes
        node_filters = filters.get('node_filters', {})
        min_degree = node_filters.get('min_degree', 0)
        
        # Build temporary graph to calculate degrees
        temp_graph = nx.DiGraph()
        for edge in self.edges:
            temp_graph.add_edge(edge.source, edge.target)
        
        # Remove isolated nodes
        nodes_to_remove = set()
        for node_id in list(self.nodes.keys()):
            degree = temp_graph.degree(node_id)
            if degree < min_degree:
                nodes_to_remove.add(node_id)
        
        for node_id in nodes_to_remove:
            del self.nodes[node_id]
        
        # Filter edges
        edge_filters = filters.get('edge_filters', {})
        min_weight = edge_filters.get('min_weight', 0)
        
        self.edges = [e for e in self.edges if e.weight >= min_weight]
        
        # Remove self-loops
        if edge_filters.get('remove_self_loops', True):
            self.edges = [e for e in self.edges if e.source != e.target]
        
        # Remove duplicates
        if edge_filters.get('remove_duplicates', True):
            seen = set()
            unique_edges = []
            for edge in self.edges:
                key = (edge.source, edge.target, edge.edge_type)
                if key not in seen:
                    seen.add(key)
                    unique_edges.append(edge)
            self.edges = unique_edges
    
    def build_networkx_graph(self):
        """Build NetworkX graph"""
        self.graph.clear()
        
        # Add nodes
        for node_iri, node in self.nodes.items():
            self.graph.add_node(node_iri, **asdict(node))
        
        # Add edges
        for edge in self.edges:
            self.graph.add_edge(edge.source, edge.target, **asdict(edge))
        
        logger.info(f"Built NetworkX graph: {self.graph.number_of_nodes()} nodes, {self.graph.number_of_edges()} edges")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get graph statistics"""
        return {
            'num_nodes': self.graph.number_of_nodes(),
            'num_edges': self.graph.number_of_edges(),
            'num_classes': sum(1 for n in self.nodes.values() if n.node_type == 'class'),
            'num_instances': sum(1 for n in self.nodes.values() if n.node_type == 'instance'),
            'num_inferred_nodes': sum(1 for n in self.nodes.values() if n.is_inferred),
            'num_inferred_edges': sum(1 for e in self.edges if e.is_inferred),
            'num_asserted_nodes': sum(1 for n in self.nodes.values() if not n.is_inferred),
            'num_asserted_edges': sum(1 for e in self.edges if not e.is_inferred),
            'avg_degree': sum(dict(self.graph.degree()).values()) / max(1, self.graph.number_of_nodes()),
            'density': nx.density(self.graph),
            'is_connected': nx.is_weakly_connected(self.graph),
            'num_connected_components': nx.number_weakly_connected_components(self.graph),
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format"""
        return {
            'nodes': {
                iri: {
                    'iri': node.iri,
                    'node_type': node.node_type,
                    'label': node.label,
                    'description': node.description,
                    'is_inferred': node.is_inferred,
                    'attributes': node.attributes,
                    'features': node.features
                }
                for iri, node in self.nodes.items()
            },
            'edges': [
                {
                    'source': edge.source,
                    'target': edge.target,
                    'edge_type': edge.edge_type,
                    'weight': edge.weight,
                    'direction': edge.direction,
                    'is_inferred': edge.is_inferred,
                    'attributes': edge.attributes
                }
                for edge in self.edges
            ]
        }
    
    def to_json(self, output_path: str):
        """Save to JSON"""
        with open(output_path, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)
        logger.info(f"Saved KG to {output_path}")
    
    def to_gexf(self, output_path: str):
        """Save to GEXF"""
        nx.write_gexf(self.graph, output_path)
        logger.info(f"Saved GEXF to {output_path}")
