"""
Knowledge Graph Extractor - Convert OWL Ontology to Knowledge Graph
Extracts nodes, edges, and features from ontology for GNN processing
"""

import logging
from pathlib import Path
from typing import Dict, List, Set, Tuple, Any, Optional
from dataclasses import dataclass, field, asdict
from collections import defaultdict
import json

import yaml
import networkx as nx
from owlready2 import get_ontology, OWLOntologyManager, sync_reasoner_hermit

logger = logging.getLogger(__name__)


@dataclass
class Node:
    """Represents a node in the knowledge graph"""
    iri: str
    node_type: str  # class, instance, property
    label: str = ""
    description: str = ""
    attributes: Dict[str, Any] = field(default_factory=dict)
    embedding: List[float] = field(default_factory=list)
    features: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Edge:
    """Represents an edge in the knowledge graph"""
    source: str
    target: str
    edge_type: str
    weight: float = 1.0
    direction: str = "directed"  # directed, undirected, both
    attributes: Dict[str, Any] = field(default_factory=dict)


class OntologyParser:
    """Parse OWL ontology using owlready2"""
    
    def __init__(self, ontology_path: str):
        self.ontology = get_ontology(f"file://{ontology_path}").load()
        self.manager = OWLOntologyManager()
        
    def get_all_classes(self) -> List[str]:
        """Get all classes in ontology"""
        return [str(cls.iri) for cls in self.ontology.classes()]
    
    def get_all_instances(self) -> List[str]:
        """Get all individuals in ontology"""
        return [str(ind.iri) for ind in self.ontology.individuals()]
    
    def get_class_label(self, class_iri: str) -> str:
        """Get human-readable label for class"""
        try:
            for cls in self.ontology.classes():
                if str(cls.iri) == class_iri:
                    if hasattr(cls, 'label') and cls.label:
                        return cls.label[0] if isinstance(cls.label, list) else str(cls.label)
        except:
            pass
        return class_iri.split('/')[-1].split('#')[-1]
    
    def get_class_description(self, class_iri: str) -> str:
        """Get description/comment for class"""
        try:
            for cls in self.ontology.classes():
                if str(cls.iri) == class_iri:
                    if hasattr(cls, 'comment') and cls.comment:
                        return cls.comment[0] if isinstance(cls.comment, list) else str(cls.comment)
        except:
            pass
        return ""
    
    def get_subclasses(self, class_iri: str, direct: bool = False) -> List[str]:
        """Get subclasses of a class"""
        try:
            for cls in self.ontology.classes():
                if str(cls.iri) == class_iri:
                    if direct:
                        return [str(sub.iri) for sub in cls.subclasses()]
                    else:
                        # Get all inferred subclasses
                        result = []
                        visited = set()
                        def get_all_subs(c):
                            for sub in c.subclasses():
                                iri = str(sub.iri)
                                if iri not in visited:
                                    visited.add(iri)
                                    result.append(iri)
                                    get_all_subs(sub)
                        get_all_subs(cls)
                        return result
        except:
            pass
        return []
    
    def get_instances_of_class(self, class_iri: str) -> List[str]:
        """Get all instances of a class"""
        try:
            for cls in self.ontology.classes():
                if str(cls.iri) == class_iri:
                    return [str(ind.iri) for ind in cls.instances()]
        except:
            pass
        return []
    
    def get_instance_types(self, instance_iri: str) -> List[str]:
        """Get types of an instance"""
        try:
            for ind in self.ontology.individuals():
                if str(ind.iri) == instance_iri:
                    return [str(cls.iri) if hasattr(cls, 'iri') else str(cls) 
                            for cls in ind.is_a if hasattr(cls, 'iri')]
        except:
            pass
        return []
    
    def get_object_properties(self, instance_iri: str) -> Dict[str, List[str]]:
        """Get all object properties and their values for an instance"""
        result = {}
        try:
            for ind in self.ontology.individuals():
                if str(ind.iri) == instance_iri:
                    for prop in self.ontology.properties():
                        if hasattr(ind, prop.name):
                            values = getattr(ind, prop.name, [])
                            if values:
                                if not isinstance(values, list):
                                    values = [values]
                                str_values = [str(v.iri) if hasattr(v, 'iri') else str(v) for v in values]
                                result[str(prop.iri)] = str_values
        except:
            pass
        return result


class KnowledgeGraphExtractor:
    """Extract knowledge graph from ontology according to rules"""
    
    def __init__(self, ontology_path: str, rules_path: str):
        """
        Args:
            ontology_path: Path to OWL ontology file
            rules_path: Path to rules.yaml configuration
        """
        self.parser = OntologyParser(ontology_path)
        self.rules = self._load_rules(rules_path)
        
        self.nodes: Dict[str, Node] = {}
        self.edges: List[Edge] = []
        self.graph = nx.DiGraph()
    
    def _load_rules(self, rules_path: str) -> Dict[str, Any]:
        """Load extraction rules from YAML"""
        with open(rules_path, 'r') as f:
            return yaml.safe_load(f)
    
    def extract_nodes(self) -> Dict[str, Node]:
        """Extract all nodes from ontology"""
        logger.info("Extracting nodes from ontology...")
        
        # Extract classes
        if self.rules['node_extraction']['classes']['enabled']:
            for class_iri in self.parser.get_all_classes():
                if self._should_include_class(class_iri):
                    label = self.parser.get_class_label(class_iri)
                    description = self.parser.get_class_description(class_iri)
                    
                    node = Node(
                        iri=class_iri,
                        node_type="class",
                        label=label,
                        description=description,
                        attributes={
                            'embedding_type': 'class_embedding'
                        }
                    )
                    self.nodes[class_iri] = node
        
        # Extract instances
        if self.rules['node_extraction']['instances']['enabled']:
            for instance_iri in self.parser.get_all_instances():
                instance_types = self.parser.get_instance_types(instance_iri)
                
                node = Node(
                    iri=instance_iri,
                    node_type="instance",
                    label=instance_iri.split('/')[-1].split('#')[-1],
                    attributes={
                        'types': instance_types,
                        'embedding_type': 'instance_embedding',
                        'properties': self.parser.get_object_properties(instance_iri)
                    }
                )
                self.nodes[instance_iri] = node
        
        logger.info(f"Extracted {len(self.nodes)} nodes")
        return self.nodes
    
    def extract_edges(self) -> List[Edge]:
        """Extract all edges from ontology"""
        logger.info("Extracting edges from ontology...")
        
        # Extract subsumption (class hierarchy)
        if self.rules['edge_extraction']['subsumption']['enabled']:
            for class_iri in self.parser.get_all_classes():
                subclasses = self.parser.get_subclasses(class_iri, direct=True)
                for sub_iri in subclasses:
                    if not self._should_exclude_edge(class_iri, sub_iri):
                        edge = Edge(
                            source=sub_iri,
                            target=class_iri,
                            edge_type="is_a",
                            weight=1.0,
                            direction="both",
                            attributes={'certainty': 1.0}
                        )
                        self.edges.append(edge)
        
        # Extract object properties
        if self.rules['edge_extraction']['object_properties']['enabled']:
            for instance_iri in self.parser.get_all_instances():
                props = self.parser.get_object_properties(instance_iri)
                for prop_iri, values in props.items():
                    prop_name = prop_iri.split('/')[-1].split('#')[-1]
                    
                    # Check exclusion filters
                    if prop_name not in self.rules['edge_extraction']['object_properties']['filters']['exclude']:
                        for target_iri in values:
                            edge = Edge(
                                source=instance_iri,
                                target=target_iri,
                                edge_type="related_to",
                                weight=0.8,
                                direction="directed",
                                attributes={'relation_type': prop_name}
                            )
                            self.edges.append(edge)
        
        # Apply data cleaning filters
        self._apply_edge_filters()
        
        logger.info(f"Extracted {len(self.edges)} edges")
        return self.edges
    
    def _should_include_class(self, class_iri: str) -> bool:
        """Check if class should be included based on filters"""
        filters = self.rules['data_cleaning']['node_filters']
        
        # Exclude specific types
        for excluded in filters['exclude_types']:
            if excluded in class_iri:
                return False
        
        # Exclude patterns
        for pattern in filters['exclude_patterns']:
            if pattern.replace('^', '').replace('.*', '') in class_iri:
                return False
        
        return True
    
    def _should_exclude_edge(self, source: str, target: str) -> bool:
        """Check if edge should be excluded based on filters"""
        filters = self.rules['data_cleaning']['edge_filters']
        
        # Remove self-loops
        if filters['remove_self_loops'] and source == target:
            return True
        
        return False
    
    def _apply_edge_filters(self):
        """Apply edge filtering rules"""
        filters = self.rules['data_cleaning']['edge_filters']
        
        # Remove low-weight edges
        self.edges = [e for e in self.edges if e.weight >= filters['min_weight']]
        
        # Remove duplicate edges
        if filters['remove_duplicates']:
            seen = set()
            unique_edges = []
            for edge in self.edges:
                key = (edge.source, edge.target, edge.edge_type)
                if key not in seen:
                    seen.add(key)
                    unique_edges.append(edge)
            self.edges = unique_edges
        
        # Remove self-loops
        if filters['remove_self_loops']:
            self.edges = [e for e in self.edges if e.source != e.target]
    
    def build_networkx_graph(self) -> nx.DiGraph:
        """Build NetworkX graph from extracted nodes and edges"""
        self.graph.clear()
        
        # Add nodes
        for node_iri, node in self.nodes.items():
            self.graph.add_node(node_iri, **asdict(node))
        
        # Add edges
        for edge in self.edges:
            self.graph.add_edge(edge.source, edge.target, **asdict(edge))
        
        logger.info(f"Built NetworkX graph: {self.graph.number_of_nodes()} nodes, {self.graph.number_of_edges()} edges")
        return self.graph
    
    def extract(self) -> Tuple[Dict[str, Node], List[Edge], nx.DiGraph]:
        """Extract complete knowledge graph"""
        self.extract_nodes()
        self.extract_edges()
        self.build_networkx_graph()
        return self.nodes, self.edges, self.graph
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format"""
        return {
            'nodes': {
                iri: {
                    'iri': node.iri,
                    'node_type': node.node_type,
                    'label': node.label,
                    'description': node.description,
                    'attributes': node.attributes,
                    'features': node.features
                }
                for iri, node in self.nodes.items()
            },
            'edges': [
                {
                    'source': edge.source,
                    'target': edge.target,
                    'edge_type': edge.edge_type,
                    'weight': edge.weight,
                    'direction': edge.direction,
                    'attributes': edge.attributes
                }
                for edge in self.edges
            ]
        }
    
    def to_json(self, output_path: str):
        """Save knowledge graph to JSON"""
        with open(output_path, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)
        logger.info(f"Saved knowledge graph to {output_path}")
    
    def to_gexf(self, output_path: str):
        """Save knowledge graph to GEXF format"""
        nx.write_gexf(self.graph, output_path)
        logger.info(f"Saved knowledge graph to {output_path}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get graph statistics"""
        return {
            'num_nodes': self.graph.number_of_nodes(),
            'num_edges': self.graph.number_of_edges(),
            'num_classes': sum(1 for n in self.nodes.values() if n.node_type == 'class'),
            'num_instances': sum(1 for n in self.nodes.values() if n.node_type == 'instance'),
            'avg_degree': sum(dict(self.graph.degree()).values()) / max(1, self.graph.number_of_nodes()),
            'density': nx.density(self.graph),
            'is_connected': nx.is_weakly_connected(self.graph),
            'num_connected_components': nx.number_weakly_connected_components(self.graph),
        }
