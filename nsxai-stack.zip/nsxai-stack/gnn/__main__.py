"""
GNN Integration Pipeline - Main orchestrator
Converts ontology to knowledge graph and applies ML integration modes
"""

import logging
import json
from pathlib import Path
from typing import Dict, Any, Optional
import yaml

from gnn.ontology_converter.extractor import KnowledgeGraphExtractor
from gnn.features.engineering import NodeFeatureEngineer, EdgeFeatureEngineer, FeatureStore
from gnn.ml_integration.modes import MLIntegrationFactory, MLConfig
from gnn.transformers.gnn_transformer import GNNTransformerPipeline

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class GNNIntegrationPipeline:
    """Complete pipeline for ontology → GNN integration"""
    
    def __init__(self, ontology_path: str, rules_path: str, output_dir: str = "./output"):
        """
        Initialize the pipeline
        
        Args:
            ontology_path: Path to OWL ontology file
            rules_path: Path to rules.yaml configuration
            output_dir: Output directory for results
        """
        self.ontology_path = ontology_path
        self.rules_path = rules_path
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Pipeline components
        self.extractor = None
        self.feature_engineer = None
        self.feature_store = FeatureStore()
        self.gnn_transformer = None
        
        # Results
        self.kg_nodes = None
        self.kg_edges = None
        self.kg_graph = None
        self.node_features = None
        self.edge_features = None
        self.gnn_transformations = None
        self.ml_results = {}
    
    def run_full_pipeline(self, ml_mode: str = "during") -> Dict[str, Any]:
        """
        Run complete pipeline from ontology to GNN
        
        Args:
            ml_mode: ML integration mode ("before", "during", "after")
        
        Returns:
            Dictionary with all results
        """
        logger.info("=" * 80)
        logger.info("STARTING GNN INTEGRATION PIPELINE")
        logger.info("=" * 80)
        
        # Step 1: Extract knowledge graph
        self._step_extract_knowledge_graph()
        
        # Step 2: Engineer features
        self._step_engineer_features()
        
        # Step 3: Transform to GNN formats
        self._step_transform_to_gnn()
        
        # Step 4: Apply ML integration mode
        self._step_ml_integration(ml_mode)
        
        # Step 5: Save results
        self._step_save_results()
        
        logger.info("=" * 80)
        logger.info("PIPELINE COMPLETE")
        logger.info("=" * 80)
        
        return self._compile_results()
    
    def _step_extract_knowledge_graph(self):
        """Extract knowledge graph from ontology"""
        logger.info("\n" + "=" * 80)
        logger.info("STEP 1: EXTRACT KNOWLEDGE GRAPH")
        logger.info("=" * 80)
        
        try:
            self.extractor = KnowledgeGraphExtractor(self.ontology_path, self.rules_path)
            self.kg_nodes, self.kg_edges, self.kg_graph = self.extractor.extract()
            
            stats = self.extractor.get_statistics()
            logger.info(f"Knowledge Graph Statistics:")
            for key, value in stats.items():
                logger.info(f"  {key}: {value}")
            
            # Save KG
            self.extractor.to_json(str(self.output_dir / "knowledge_graph.json"))
            self.extractor.to_gexf(str(self.output_dir / "knowledge_graph.gexf"))
            
        except Exception as e:
            logger.error(f"Failed to extract knowledge graph: {e}")
            raise
    
    def _step_engineer_features(self):
        """Engineer node and edge features"""
        logger.info("\n" + "=" * 80)
        logger.info("STEP 2: ENGINEER FEATURES")
        logger.info("=" * 80)
        
        try:
            # Node features
            node_engineer = NodeFeatureEngineer(self.kg_graph, self.kg_nodes)
            self.node_features = node_engineer.engineer_features()
            self.node_features = node_engineer.normalize_features(method="standardize")
            
            logger.info(f"Generated node features: {len(self.node_features)} nodes")
            
            # Edge features
            edge_engineer = EdgeFeatureEngineer(self.kg_graph, self.kg_edges)
            self.edge_features = edge_engineer.engineer_features()
            
            logger.info(f"Generated edge features: {len(self.edge_features)} edges")
            
            # Store features
            self.feature_store.node_features = self.node_features
            self.feature_store.edge_features = self.edge_features
            self.feature_store.metadata = {
                'num_nodes': len(self.node_features),
                'num_edges': len(self.edge_features),
                'node_feature_dim': next(iter(self.node_features.values())).shape[0] if self.node_features else 0
            }
            
        except Exception as e:
            logger.error(f"Failed to engineer features: {e}")
            raise
    
    def _step_transform_to_gnn(self):
        """Transform knowledge graph to GNN-compatible formats"""
        logger.info("\n" + "=" * 80)
        logger.info("STEP 3: TRANSFORM TO GNN FORMATS")
        logger.info("=" * 80)
        
        try:
            self.gnn_transformer = GNNTransformerPipeline(
                self.kg_graph,
                self.kg_nodes,
                self.kg_edges,
                self.node_features,
                self.edge_features
            )
            
            self.gnn_transformations = self.gnn_transformer.transform_all()
            
            logger.info(f"Generated {len(self.gnn_transformations)} GNN formats:")
            for fmt in self.gnn_transformations.keys():
                logger.info(f"  - {fmt}")
            
            # Save all formats
            self.gnn_transformer.save_all(str(self.output_dir / "gnn_formats"))
            
        except Exception as e:
            logger.error(f"Failed to transform to GNN formats: {e}")
            raise
    
    def _step_ml_integration(self, ml_mode: str):
        """Apply ML integration mode"""
        logger.info("\n" + "=" * 80)
        logger.info(f"STEP 4: ML INTEGRATION - Mode: {ml_mode.upper()}")
        logger.info("=" * 80)
        
        try:
            # Create ML config
            config = MLConfig(
                mode=ml_mode,
                graph=self.kg_graph,
                node_features=self.node_features,
                edge_features=self.edge_features
            )
            
            # Create and run integration mode
            integration = MLIntegrationFactory.create(ml_mode, config)
            self.ml_results[ml_mode] = integration.process()
            
            logger.info(f"ML Integration Mode '{ml_mode}' completed")
            logger.info(f"Output format: {integration.get_output_format()}")
            
        except Exception as e:
            logger.error(f"Failed to apply ML integration mode: {e}")
            raise
    
    def _step_save_results(self):
        """Save all results"""
        logger.info("\n" + "=" * 80)
        logger.info("STEP 5: SAVE RESULTS")
        logger.info("=" * 80)
        
        try:
            # Save features
            self.feature_store.save(str(self.output_dir / "features.pkl"))
            
            # Save ML results
            for mode, results in self.ml_results.items():
                ml_output = self.output_dir / f"ml_integration_{mode}.json"
                
                # Convert numpy arrays to lists for JSON serialization
                serializable_results = self._make_serializable(results)
                with open(ml_output, 'w') as f:
                    json.dump(serializable_results, f, indent=2, default=str)
                
                logger.info(f"Saved ML results: {ml_output}")
            
            # Save pipeline metadata
            metadata = {
                'ontology_path': str(self.ontology_path),
                'rules_path': str(self.rules_path),
                'kg_nodes': len(self.kg_nodes),
                'kg_edges': len(self.kg_edges),
                'node_feature_dim': next(iter(self.node_features.values())).shape[0] if self.node_features else 0,
                'gnn_formats': list(self.gnn_transformations.keys()),
                'ml_modes': list(self.ml_results.keys())
            }
            with open(self.output_dir / "metadata.json", 'w') as f:
                json.dump(metadata, f, indent=2)
            
            logger.info(f"Saved metadata: {self.output_dir / 'metadata.json'}")
            
        except Exception as e:
            logger.error(f"Failed to save results: {e}")
            raise
    
    def _make_serializable(self, obj):
        """Convert numpy arrays and other non-serializable objects"""
        if isinstance(obj, dict):
            return {k: self._make_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [self._make_serializable(v) for v in obj]
        elif hasattr(obj, 'tolist'):  # numpy array
            return obj.tolist()
        else:
            return obj
    
    def _compile_results(self) -> Dict[str, Any]:
        """Compile all results"""
        return {
            'knowledge_graph': {
                'num_nodes': len(self.kg_nodes),
                'num_edges': len(self.kg_edges),
                'graph_file': 'knowledge_graph.json',
                'gexf_file': 'knowledge_graph.gexf'
            },
            'features': {
                'num_node_features': next(iter(self.node_features.values())).shape[0] if self.node_features else 0,
                'num_nodes': len(self.node_features),
                'num_edge_features': len(self.edge_features),
                'features_file': 'features.pkl'
            },
            'gnn_transformations': {
                fmt: {
                    'num_nodes': trans['num_nodes'],
                    'num_edges': trans['num_edges'],
                    'num_features': trans['num_features']
                }
                for fmt, trans in self.gnn_transformations.items()
            },
            'ml_integration': {
                mode: {
                    'output_file': f'ml_integration_{mode}.json',
                    'output_format': 'See file for details'
                }
                for mode in self.ml_results.keys()
            },
            'output_directory': str(self.output_dir)
        }
    
    def run_all_ml_modes(self) -> Dict[str, Dict[str, Any]]:
        """Run pipeline with all ML integration modes"""
        logger.info("\nRunning with ALL ML modes...")
        
        results = {}
        for mode in ['before', 'during', 'after']:
            logger.info(f"\n>>> Running with mode: {mode}")
            config = MLConfig(
                mode=mode,
                graph=self.kg_graph,
                node_features=self.node_features,
                edge_features=self.edge_features
            )
            integration = MLIntegrationFactory.create(mode, config)
            results[mode] = integration.process()
        
        self.ml_results.update(results)
        return results


def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='GNN Integration Pipeline')
    parser.add_argument('--ontology', required=True, help='Path to OWL ontology file')
    parser.add_argument('--rules', required=True, help='Path to rules.yaml configuration')
    parser.add_argument('--output', default='./output', help='Output directory')
    parser.add_argument('--mode', default='during', choices=['before', 'during', 'after', 'all'],
                       help='ML integration mode')
    
    args = parser.parse_args()
    
    # Run pipeline
    pipeline = GNNIntegrationPipeline(args.ontology, args.rules, args.output)
    
    if args.mode == 'all':
        results = {}
        # First extract and transform
        pipeline._step_extract_knowledge_graph()
        pipeline._step_engineer_features()
        pipeline._step_transform_to_gnn()
        
        # Then run all modes
        all_mode_results = pipeline.run_all_ml_modes()
        results.update(all_mode_results)
        
        # Save
        pipeline._step_save_results()
        final = pipeline._compile_results()
    else:
        final = pipeline.run_full_pipeline(ml_mode=args.mode)
    
    print("\n" + "=" * 80)
    print("PIPELINE RESULTS")
    print("=" * 80)
    print(json.dumps(final, indent=2))
    
    return final


if __name__ == '__main__':
    main()
