"""
REST API for GNN Integration and Hermit Reasoning
Exposes GNN pipeline and ontology reasoning capabilities via REST endpoints
"""

import logging
import json
from pathlib import Path
from typing import Dict, Any, Optional
import os

from flask import Flask, request, jsonify
from flask_cors import CORS

logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Configuration
ONTOLOGY_DIR = os.getenv("ONTOLOGY_DIR", "/ontologies")
RULES_PATH = os.getenv("RULES_PATH", "/app/config/rules.yaml")
OUTPUT_DIR = os.getenv("OUTPUT_DIR", "/output")

# Initialize pipeline on demand
_pipeline_cache = {}


def _get_pipeline():
    """Get or create GNN pipeline instance"""
    if 'pipeline' not in _pipeline_cache:
        try:
            from gnn import GNNIntegrationPipeline
            _pipeline_cache['pipeline'] = GNNIntegrationPipeline(
                ontology_path=f"{ONTOLOGY_DIR}/gato.owl",
                rules_path=RULES_PATH,
                output_dir=OUTPUT_DIR
            )
        except Exception as e:
            logger.error(f"Failed to initialize pipeline: {e}")
            return None
    return _pipeline_cache['pipeline']


# ── Health Check ──
@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'ok',
        'service': 'gnn-api',
        'ontology_dir': ONTOLOGY_DIR,
        'output_dir': OUTPUT_DIR
    })


# ── GNN Extraction ──
@app.route('/gnn/extract', methods=['POST'])
def gnn_extract():
    """Extract knowledge graph from ontology"""
    try:
        pipeline = _get_pipeline()
        if not pipeline:
            return jsonify({'error': 'Failed to initialize pipeline'}), 500
        
        pipeline._step_extract_knowledge_graph()
        
        stats = pipeline.extractor.get_statistics()
        
        return jsonify({
            'status': 'success',
            'message': 'Knowledge graph extracted',
            'statistics': stats,
            'output_files': {
                'json': 'knowledge_graph.json',
                'gexf': 'knowledge_graph.gexf'
            }
        })
    except Exception as e:
        logger.error(f"Extraction failed: {e}")
        return jsonify({'error': str(e)}), 400


# ── Feature Engineering ──
@app.route('/gnn/features', methods=['POST'])
def gnn_features():
    """Engineer node and edge features"""
    try:
        pipeline = _get_pipeline()
        if not pipeline:
            return jsonify({'error': 'Failed to initialize pipeline'}), 500
        
        # Extract first if needed
        if pipeline.kg_nodes is None:
            pipeline._step_extract_knowledge_graph()
        
        pipeline._step_engineer_features()
        
        return jsonify({
            'status': 'success',
            'message': 'Features engineered',
            'node_features': len(pipeline.node_features),
            'edge_features': len(pipeline.edge_features),
            'feature_dimension': next(iter(pipeline.node_features.values())).shape[0]
        })
    except Exception as e:
        logger.error(f"Feature engineering failed: {e}")
        return jsonify({'error': str(e)}), 400


# ── GNN Transformation ──
@app.route('/gnn/transform', methods=['POST'])
def gnn_transform():
    """Transform to GNN-compatible formats"""
    try:
        data = request.get_json() or {}
        formats = data.get('formats', ['pytorch_geometric', 'dgl', 'networkx', 'gexf'])
        
        pipeline = _get_pipeline()
        if not pipeline:
            return jsonify({'error': 'Failed to initialize pipeline'}), 500
        
        # Extract and engineer if needed
        if pipeline.kg_nodes is None:
            pipeline._step_extract_knowledge_graph()
            pipeline._step_engineer_features()
        
        pipeline._step_transform_to_gnn()
        
        return jsonify({
            'status': 'success',
            'message': 'Transformed to GNN formats',
            'formats': list(pipeline.gnn_transformations.keys()),
            'output_directory': 'gnn_formats/'
        })
    except Exception as e:
        logger.error(f"Transformation failed: {e}")
        return jsonify({'error': str(e)}), 400


# ── ML Integration ──
@app.route('/gnn/ml-integrate', methods=['POST'])
def gnn_ml_integrate():
    """Apply ML integration mode"""
    try:
        data = request.get_json() or {}
        mode = data.get('mode', 'during')
        
        if mode not in ['before', 'during', 'after']:
            return jsonify({'error': f'Invalid mode: {mode}'}), 400
        
        pipeline = _get_pipeline()
        if not pipeline:
            return jsonify({'error': 'Failed to initialize pipeline'}), 500
        
        # Run full pipeline
        results = pipeline.run_full_pipeline(ml_mode=mode)
        
        return jsonify({
            'status': 'success',
            'message': f'ML integration mode "{mode}" applied',
            'mode': mode,
            'results': results
        })
    except Exception as e:
        logger.error(f"ML integration failed: {e}")
        return jsonify({'error': str(e)}), 400


# ── All Modes ──
@app.route('/gnn/ml-integrate-all', methods=['POST'])
def gnn_ml_integrate_all():
    """Run all ML integration modes"""
    try:
        pipeline = _get_pipeline()
        if not pipeline:
            return jsonify({'error': 'Failed to initialize pipeline'}), 500
        
        # Extract and engineer first
        pipeline._step_extract_knowledge_graph()
        pipeline._step_engineer_features()
        pipeline._step_transform_to_gnn()
        
        # Run all modes
        all_results = pipeline.run_all_ml_modes()
        
        return jsonify({
            'status': 'success',
            'message': 'All ML integration modes completed',
            'modes': list(all_results.keys()),
            'output_files': {
                mode: f'ml_integration_{mode}.json'
                for mode in all_results.keys()
            }
        })
    except Exception as e:
        logger.error(f"All modes failed: {e}")
        return jsonify({'error': str(e)}), 400


# ── Pipeline Status ──
@app.route('/gnn/status', methods=['GET'])
def gnn_status():
    """Get pipeline status and configuration"""
    try:
        pipeline = _get_pipeline()
        
        return jsonify({
            'ontology_path': str(pipeline.ontology_path) if pipeline else None,
            'rules_path': str(pipeline.rules_path) if pipeline else None,
            'output_dir': str(pipeline.output_dir) if pipeline else None,
            'extraction_complete': pipeline.kg_nodes is not None if pipeline else False,
            'features_complete': pipeline.node_features is not None if pipeline else False,
            'transformation_complete': pipeline.gnn_transformations is not None if pipeline else False,
            'ml_modes_applied': list(pipeline.ml_results.keys()) if pipeline else []
        })
    except Exception as e:
        logger.error(f"Status check failed: {e}")
        return jsonify({'error': str(e)}), 400


# ── List Output Files ──
@app.route('/gnn/outputs', methods=['GET'])
def gnn_outputs():
    """List all generated output files"""
    try:
        output_path = Path(OUTPUT_DIR)
        files = {}
        
        if output_path.exists():
            for file in sorted(output_path.rglob('*')):
                if file.is_file():
                    rel_path = str(file.relative_to(output_path))
                    files[rel_path] = {
                        'size_bytes': file.stat().st_size,
                        'modified': str(file.stat().st_mtime)
                    }
        
        return jsonify({
            'output_directory': str(output_path),
            'files': files
        })
    except Exception as e:
        logger.error(f"Output listing failed: {e}")
        return jsonify({'error': str(e)}), 400


# ── Error Handlers ──
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404


@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    logger.info(f"Starting GNN REST API...")
    logger.info(f"Ontology directory: {ONTOLOGY_DIR}")
    logger.info(f"Rules path: {RULES_PATH}")
    logger.info(f"Output directory: {OUTPUT_DIR}")
    
    app.run(host='0.0.0.0', port=8000, debug=False)
