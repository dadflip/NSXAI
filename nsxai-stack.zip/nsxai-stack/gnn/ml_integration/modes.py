"""
ML Integration Modes - Three strategies for integrating ontology with ML
- BEFORE: Use graph for input augmentation
- DURING: End-to-end GNN reasoning
- AFTER: Post-processing validation
"""

import logging
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Tuple, Optional
import numpy as np
import networkx as nx
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class MLConfig:
    """Configuration for ML integration"""
    mode: str  # "before", "during", "after"
    input_features: Optional[np.ndarray] = None
    graph: Optional[nx.DiGraph] = None
    node_features: Optional[Dict[str, np.ndarray]] = None
    edge_features: Optional[Dict[Tuple[str, str], np.ndarray]] = None
    reasoning_rules: Optional[Dict[str, Any]] = None


class MLIntegrationMode(ABC):
    """Base class for ML integration modes"""
    
    def __init__(self, config: MLConfig):
        self.config = config
        self.predictions = None
        self.confidence_scores = None
    
    @abstractmethod
    def process(self) -> Dict[str, Any]:
        """Process according to integration mode"""
        pass
    
    @abstractmethod
    def get_output_format(self) -> str:
        """Get output format description"""
        pass


class BeforeInferenceMode(MLIntegrationMode):
    """
    MODE 1: BEFORE INFERENCE
    Use graph to augment input features before neural network prediction
    
    Pipeline:
    1. Extract knowledge graph from ontology
    2. Generate node embeddings and graph features
    3. Augment original features with graph context
    4. Train/predict with enhanced features
    """
    
    def __init__(self, config: MLConfig):
        super().__init__(config)
        self.augmented_features = None
        self.feature_importance = None
    
    def process(self) -> Dict[str, Any]:
        """Process before inference"""
        logger.info("=" * 60)
        logger.info("MODE 1: BEFORE INFERENCE - Input Augmentation")
        logger.info("=" * 60)
        
        # Step 1: Extract graph context for each node
        graph_context = self._extract_graph_context()
        logger.info(f"Extracted context for {len(graph_context)} nodes")
        
        # Step 2: Generate semantic embeddings
        semantic_embeddings = self._generate_semantic_embeddings()
        logger.info(f"Generated {len(semantic_embeddings)} semantic embeddings")
        
        # Step 3: Augment original features
        self.augmented_features = self._augment_features(
            self.config.input_features,
            graph_context,
            semantic_embeddings
        )
        logger.info(f"Augmented features shape: {self.augmented_features.shape}")
        
        # Step 4: Compute feature importance
        self.feature_importance = self._compute_feature_importance()
        
        return {
            'mode': 'before_inference',
            'augmented_features': self.augmented_features,
            'feature_importance': self.feature_importance,
            'graph_context': graph_context,
            'semantic_embeddings': semantic_embeddings,
            'description': 'Features augmented with graph context before neural prediction'
        }
    
    def _extract_graph_context(self) -> Dict[str, Dict[str, Any]]:
        """Extract local graph context for each node"""
        graph_context = {}
        
        for node_id in self.config.graph.nodes():
            neighbors = list(self.config.graph.neighbors(node_id))
            predecessors = list(self.config.graph.predecessors(node_id))
            successors = list(self.config.graph.successors(node_id))
            
            # Compute local aggregation
            neighbor_features = []
            if node_id in self.config.node_features:
                for neighbor in neighbors[:10]:  # Limit to 10 neighbors
                    if neighbor in self.config.node_features:
                        neighbor_features.append(self.config.node_features[neighbor])
            
            if neighbor_features:
                aggregated = np.mean(neighbor_features, axis=0)
            else:
                aggregated = np.zeros_like(self.config.node_features.get(node_id, np.zeros(1)))
            
            graph_context[node_id] = {
                'num_neighbors': len(neighbors),
                'num_predecessors': len(predecessors),
                'num_successors': len(successors),
                'aggregated_neighbor_features': aggregated,
                'degree': len(neighbors) + len(predecessors)
            }
        
        return graph_context
    
    def _generate_semantic_embeddings(self) -> Dict[str, np.ndarray]:
        """Generate semantic embeddings from graph structure"""
        embeddings = {}
        
        # Use node features as semantic embeddings
        for node_id, features in self.config.node_features.items():
            embeddings[node_id] = features
        
        return embeddings
    
    def _augment_features(self, original_features: np.ndarray, 
                         graph_context: Dict, 
                         embeddings: Dict) -> np.ndarray:
        """Augment original features with graph information"""
        
        augmentation_list = []
        
        for node_id in sorted(embeddings.keys()):
            original = original_features if isinstance(original_features, np.ndarray) else np.zeros(1)
            context = graph_context.get(node_id, {})
            embedding = embeddings.get(node_id, np.zeros(1))
            
            # Combine: original + embedding + context metrics
            neighbor_agg = context.get('aggregated_neighbor_features', np.zeros_like(embedding))
            context_features = np.array([
                context.get('num_neighbors', 0),
                context.get('num_predecessors', 0),
                context.get('num_successors', 0),
                context.get('degree', 0)
            ])
            
            augmented = np.concatenate([
                embedding,
                neighbor_agg,
                context_features
            ])
            augmentation_list.append(augmented)
        
        return np.array(augmentation_list)
    
    def _compute_feature_importance(self) -> Dict[str, float]:
        """Compute importance of augmented features"""
        if self.augmented_features is None:
            return {}
        
        # Variance-based importance
        importance = {}
        for i, feature_name in enumerate(['embedding', 'neighbor_agg', 'num_neighbors', 
                                          'num_predecessors', 'num_successors', 'degree']):
            if i < self.augmented_features.shape[1]:
                importance[feature_name] = float(np.var(self.augmented_features[:, i]))
        
        # Normalize
        total = sum(importance.values())
        if total > 0:
            importance = {k: v / total for k, v in importance.items()}
        
        return importance
    
    def get_output_format(self) -> str:
        return "feature_vectors: Enhanced input for neural networks"


class DuringInferenceMode(MLIntegrationMode):
    """
    MODE 2: DURING INFERENCE
    Use GNN (Graph Neural Network) for end-to-end reasoning
    
    Pipeline:
    1. Build GNN architecture (GCN, GraphSAGE, GAT, etc.)
    2. Initialize with node and edge features
    3. Message passing on knowledge graph
    4. Output node embeddings and classifications
    """
    
    def __init__(self, config: MLConfig):
        super().__init__(config)
        self.gnn_output = None
        self.node_embeddings = None
        self.attention_weights = None
    
    def process(self) -> Dict[str, Any]:
        """Process during inference with GNN"""
        logger.info("=" * 60)
        logger.info("MODE 2: DURING INFERENCE - GNN End-to-End Reasoning")
        logger.info("=" * 60)
        
        # Step 1: Prepare graph structure
        adjacency_matrix = self._build_adjacency_matrix()
        logger.info(f"Built adjacency matrix: {adjacency_matrix.shape}")
        
        # Step 2: Initialize node embeddings
        self.node_embeddings = self._initialize_node_embeddings()
        logger.info(f"Initialized node embeddings: {len(self.node_embeddings)}")
        
        # Step 3: Message passing (simulate GNN layers)
        self.node_embeddings = self._message_passing(adjacency_matrix, iterations=3)
        logger.info("Completed 3 iterations of message passing")
        
        # Step 4: Generate predictions
        predictions = self._generate_predictions()
        self.attention_weights = self._compute_attention_weights()
        
        return {
            'mode': 'during_inference',
            'node_embeddings': self.node_embeddings,
            'predictions': predictions,
            'attention_weights': self.attention_weights,
            'adjacency_matrix': adjacency_matrix,
            'description': 'GNN-based reasoning directly on knowledge graph'
        }
    
    def _build_adjacency_matrix(self) -> np.ndarray:
        """Build adjacency matrix from graph"""
        nodes = sorted(self.config.graph.nodes())
        n = len(nodes)
        node_to_idx = {node: i for i, node in enumerate(nodes)}
        
        adj = np.zeros((n, n))
        for source, target, data in self.config.graph.edges(data=True):
            i = node_to_idx[source]
            j = node_to_idx[target]
            weight = data.get('weight', 1.0)
            adj[i, j] = weight
            # Bidirectional
            adj[j, i] = weight
        
        # Add self-loops
        np.fill_diagonal(adj, 1.0)
        
        return adj
    
    def _initialize_node_embeddings(self) -> Dict[str, np.ndarray]:
        """Initialize embeddings from node features"""
        embeddings = {}
        for node_id, features in self.config.node_features.items():
            embeddings[node_id] = features.copy()
        return embeddings
    
    def _message_passing(self, adjacency: np.ndarray, iterations: int = 3) -> Dict[str, np.ndarray]:
        """Simulate GNN message passing"""
        nodes = sorted(self.config.node_features.keys())
        node_to_idx = {node: i for i, node in enumerate(nodes)}
        
        # Stack embeddings for matrix operations
        embeddings = np.array([self.node_embeddings[n] for n in nodes])
        
        for layer in range(iterations):
            logger.info(f"Message passing layer {layer + 1}/{iterations}")
            
            # Aggregate neighbor information
            aggregated = adjacency @ embeddings
            
            # Normalize by degree
            degree = adjacency.sum(axis=1, keepdims=True)
            degree[degree == 0] = 1
            aggregated = aggregated / degree
            
            # Apply activation and update (simplified GNN)
            embeddings = np.tanh(aggregated + embeddings * 0.5)
        
        # Convert back to dict
        result = {}
        for i, node in enumerate(nodes):
            result[node] = embeddings[i]
        
        return result
    
    def _generate_predictions(self) -> Dict[str, np.ndarray]:
        """Generate node classifications from embeddings"""
        predictions = {}
        for node_id, embedding in self.node_embeddings.items():
            # Softmax-like output
            scores = embedding / (np.linalg.norm(embedding) + 1e-8)
            predictions[node_id] = np.abs(scores[:10]) if len(scores) > 10 else np.abs(scores)
        
        return predictions
    
    def _compute_attention_weights(self) -> Dict[str, float]:
        """Compute attention/importance weights for nodes"""
        weights = {}
        for node_id, embedding in self.node_embeddings.items():
            # Compute based on embedding magnitude
            weights[node_id] = float(np.linalg.norm(embedding))
        
        # Normalize
        total = sum(weights.values())
        if total > 0:
            weights = {k: v / total for k, v in weights.items()}
        
        return weights
    
    def get_output_format(self) -> str:
        return "graph_embeddings: Node representations from GNN"


class AfterInferenceMode(MLIntegrationMode):
    """
    MODE 3: AFTER INFERENCE
    Use ontology to validate and correct predictions
    
    Pipeline:
    1. Get neural predictions
    2. Check consistency against ontology rules
    3. Apply constraint satisfaction
    4. Output verified predictions
    """
    
    def __init__(self, config: MLConfig):
        super().__init__(config)
        self.verified_predictions = None
        self.corrections = None
    
    def process(self) -> Dict[str, Any]:
        """Process after neural inference"""
        logger.info("=" * 60)
        logger.info("MODE 3: AFTER INFERENCE - Symbolic Validation")
        logger.info("=" * 60)
        
        # Step 1: Check consistency
        consistency_results = self._consistency_check()
        logger.info(f"Consistency check: {len(consistency_results)} issues found")
        
        # Step 2: Apply corrections
        self.corrections = self._apply_corrections(consistency_results)
        logger.info(f"Applied {len(self.corrections)} corrections")
        
        # Step 3: Verify predictions
        self.verified_predictions = self._verify_predictions()
        
        # Step 4: Generate explanations
        explanations = self._generate_explanations()
        
        return {
            'mode': 'after_inference',
            'verified_predictions': self.verified_predictions,
            'corrections': self.corrections,
            'consistency_results': consistency_results,
            'explanations': explanations,
            'description': 'Predictions validated and corrected using ontology constraints'
        }
    
    def _consistency_check(self) -> List[Dict[str, Any]]:
        """Check predictions against ontology rules"""
        issues = []
        
        if not self.config.reasoning_rules:
            return issues
        
        # Check type consistency
        for node_id, pred in self.predictions.items():
            # Example: Check if instance is consistent with its class
            node_data = self.config.graph.nodes[node_id] if node_id in self.config.graph else {}
            
            # Simulate consistency checking
            if hasattr(node_data, 'node_type') and node_data.node_type == 'instance':
                # Check against class hierarchy
                neighbors = list(self.config.graph.neighbors(node_id))
                if len(neighbors) == 0:
                    issues.append({
                        'node': node_id,
                        'issue': 'No class assignment found',
                        'severity': 'warning'
                    })
        
        return issues
    
    def _apply_corrections(self, issues: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Apply corrections based on ontology constraints"""
        corrections = {}
        
        for issue in issues:
            node_id = issue['node']
            severity = issue['severity']
            
            if severity == 'critical':
                # Find most likely correct class from ontology
                candidates = []
                if node_id in self.config.graph:
                    for neighbor in self.config.graph.neighbors(node_id):
                        candidates.append(neighbor)
                
                if candidates:
                    corrections[node_id] = {
                        'original': self.predictions.get(node_id),
                        'corrected': candidates[0],
                        'method': 'ontology_constraint'
                    }
        
        return corrections
    
    def _verify_predictions(self) -> Dict[str, Dict[str, Any]]:
        """Verify all predictions"""
        verified = {}
        
        for node_id, pred in self.predictions.items():
            if node_id in self.corrections:
                verified[node_id] = {
                    'prediction': self.corrections[node_id]['corrected'],
                    'confidence': 0.95,
                    'verified': True,
                    'correction_applied': True
                }
            else:
                verified[node_id] = {
                    'prediction': pred,
                    'confidence': 0.85,
                    'verified': True,
                    'correction_applied': False
                }
        
        return verified
    
    def _generate_explanations(self) -> Dict[str, str]:
        """Generate explanations for predictions"""
        explanations = {}
        
        for node_id, verified in self.verified_predictions.items():
            if verified['correction_applied']:
                explanations[node_id] = f"Prediction corrected using ontology constraints"
            else:
                explanations[node_id] = f"Prediction consistent with ontology (confidence: {verified['confidence']:.2f})"
        
        return explanations
    
    def get_output_format(self) -> str:
        return "verified_predictions: Neural predictions validated by symbolic reasoning"


class MLIntegrationFactory:
    """Factory to create ML integration mode instances"""
    
    _modes = {
        'before': BeforeInferenceMode,
        'during': DuringInferenceMode,
        'after': AfterInferenceMode,
    }
    
    @staticmethod
    def create(mode: str, config: MLConfig) -> MLIntegrationMode:
        """Create ML integration mode instance"""
        if mode not in MLIntegrationFactory._modes:
            raise ValueError(f"Unknown mode: {mode}. Available: {list(MLIntegrationFactory._modes.keys())}")
        
        return MLIntegrationFactory._modes[mode](config)
    
    @staticmethod
    def get_available_modes() -> List[str]:
        """Get list of available modes"""
        return list(MLIntegrationFactory._modes.keys())
