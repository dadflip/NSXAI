"""
GNN/GCNN Transformations - Convert knowledge graph to GNN-compatible formats
Supports PyTorch Geometric, DGL, and other popular frameworks
"""

import logging
from typing import Dict, Tuple, List, Any, Optional
import numpy as np
import networkx as nx
from pathlib import Path
import json

logger = logging.getLogger(__name__)


class PyTorchGeometricTransformer:
    """Transform knowledge graph to PyTorch Geometric format"""
    
    def __init__(self, graph: nx.DiGraph, node_features: Dict[str, np.ndarray], 
                 edge_features: Dict[Tuple[str, str], np.ndarray]):
        self.graph = graph
        self.node_features = node_features
        self.edge_features = edge_features
        
        try:
            import torch
            from torch_geometric.data import Data
            self.torch = torch
            self.Data = Data
        except ImportError:
            logger.warning("PyTorch Geometric not installed")
            self.torch = None
    
    def transform(self) -> Optional[Dict[str, Any]]:
        """Transform to PyTorch Geometric format"""
        if self.torch is None:
            logger.warning("Skipping PyTorch Geometric transformation (not installed)")
            return None
        
        logger.info("Transforming to PyTorch Geometric format...")
        
        # Create node mapping
        nodes = sorted(self.graph.nodes())
        node_to_idx = {node: i for i, node in enumerate(nodes)}
        
        # Create node features tensor
        x = self.torch.FloatTensor([
            self.node_features.get(node, np.zeros(1))
            for node in nodes
        ])
        
        # Create edge indices
        edge_list = list(self.graph.edges())
        if edge_list:
            edge_index = self.torch.LongTensor([
                [node_to_idx[src] for src, tgt in edge_list],
                [node_to_idx[tgt] for src, tgt in edge_list]
            ])
        else:
            edge_index = self.torch.LongTensor(2, 0)
        
        # Create edge attributes if available
        edge_attr = None
        if self.edge_features:
            edge_attr_list = []
            for src, tgt in edge_list:
                feat = self.edge_features.get((src, tgt), np.zeros(1))
                edge_attr_list.append(feat)
            if edge_attr_list:
                edge_attr = self.torch.FloatTensor(edge_attr_list)
        
        # Create PyTorch Geometric Data object
        data = self.Data(
            x=x,
            edge_index=edge_index,
            edge_attr=edge_attr,
            node_names=nodes,
            num_nodes=len(nodes)
        )
        
        logger.info(f"Created PyTorch Geometric Data: nodes={data.num_nodes}, edges={data.num_edges}")
        
        return {
            'format': 'pytorch_geometric',
            'data': data,
            'node_to_idx': node_to_idx,
            'num_features': x.shape[1],
            'num_nodes': len(nodes),
            'num_edges': len(edge_list)
        }


class DGLTransformer:
    """Transform knowledge graph to DGL (Deep Graph Library) format"""
    
    def __init__(self, graph: nx.DiGraph, node_features: Dict[str, np.ndarray], 
                 edge_features: Dict[Tuple[str, str], np.ndarray]):
        self.graph = graph
        self.node_features = node_features
        self.edge_features = edge_features
        
        try:
            import dgl
            import torch
            self.dgl = dgl
            self.torch = torch
        except ImportError:
            logger.warning("DGL not installed")
            self.dgl = None
    
    def transform(self) -> Optional[Dict[str, Any]]:
        """Transform to DGL format"""
        if self.dgl is None:
            logger.warning("Skipping DGL transformation (not installed)")
            return None
        
        logger.info("Transforming to DGL format...")
        
        # Create node mapping
        nodes = sorted(self.graph.nodes())
        node_to_idx = {node: i for i, node in enumerate(nodes)}
        
        # Create edge list
        edge_list = list(self.graph.edges())
        if edge_list:
            src_nodes = [node_to_idx[src] for src, tgt in edge_list]
            dst_nodes = [node_to_idx[tgt] for src, tgt in edge_list]
        else:
            src_nodes, dst_nodes = [], []
        
        # Create DGL graph
        dgl_graph = self.dgl.graph((src_nodes, dst_nodes), num_nodes=len(nodes))
        
        # Add node features
        node_feat_array = np.array([
            self.node_features.get(node, np.zeros(1))
            for node in nodes
        ])
        dgl_graph.ndata['feat'] = self.torch.FloatTensor(node_feat_array)
        
        # Add edge features if available
        if self.edge_features and edge_list:
            edge_feat_array = np.array([
                self.edge_features.get((src, tgt), np.zeros(1))
                for src, tgt in edge_list
            ])
            dgl_graph.edata['feat'] = self.torch.FloatTensor(edge_feat_array)
        
        logger.info(f"Created DGL Graph: nodes={dgl_graph.num_nodes()}, edges={dgl_graph.num_edges()}")
        
        return {
            'format': 'dgl',
            'graph': dgl_graph,
            'node_to_idx': node_to_idx,
            'num_features': node_feat_array.shape[1],
            'num_nodes': len(nodes),
            'num_edges': len(edge_list)
        }


class NetworkXTransformer:
    """Transform and export as NetworkX format"""
    
    def __init__(self, graph: nx.DiGraph, node_features: Dict[str, np.ndarray], 
                 edge_features: Dict[Tuple[str, str], np.ndarray]):
        self.graph = graph.copy()
        self.node_features = node_features
        self.edge_features = edge_features
    
    def transform(self) -> Dict[str, Any]:
        """Add features to NetworkX graph"""
        logger.info("Adding features to NetworkX graph...")
        
        # Add node features
        for node in self.graph.nodes():
            if node in self.node_features:
                self.graph.nodes[node]['features'] = self.node_features[node].tolist()
        
        # Add edge features
        for src, tgt in self.graph.edges():
            if (src, tgt) in self.edge_features:
                self.graph[src][tgt]['features'] = self.edge_features[(src, tgt)].tolist()
        
        logger.info(f"Enhanced NetworkX Graph: {self.graph.number_of_nodes()} nodes, {self.graph.number_of_edges()} edges")
        
        return {
            'format': 'networkx',
            'graph': self.graph,
            'num_nodes': self.graph.number_of_nodes(),
            'num_edges': self.graph.number_of_edges()
        }


class GEXFTransformer:
    """Export knowledge graph to GEXF format (Graph Exchange XML Format)"""
    
    def __init__(self, graph: nx.DiGraph, node_features: Dict[str, np.ndarray]):
        self.graph = graph.copy()
        self.node_features = node_features
    
    def transform(self, output_path: str) -> str:
        """Export to GEXF format"""
        logger.info(f"Exporting to GEXF: {output_path}")
        
        # Add features to graph
        for node in self.graph.nodes():
            if node in self.node_features:
                # Store feature dimension in node attributes
                self.graph.nodes[node]['feature_dim'] = len(self.node_features[node])
        
        # Write GEXF
        nx.write_gexf(self.graph, output_path)
        logger.info(f"Exported GEXF: {output_path}")
        
        return output_path


class GNNTransformerPipeline:
    """Complete pipeline for transforming ontology to GNN-ready formats"""
    
    def __init__(self, graph: nx.DiGraph, nodes: Dict[str, Any], edges: List[Dict[str, Any]],
                 node_features: Dict[str, np.ndarray], edge_features: Dict[Tuple[str, str], np.ndarray]):
        self.graph = graph
        self.nodes = nodes
        self.edges = edges
        self.node_features = node_features
        self.edge_features = edge_features
        self.transformations = {}
    
    def transform_all(self) -> Dict[str, Dict[str, Any]]:
        """Transform to all available formats"""
        logger.info("=" * 60)
        logger.info("GNN TRANSFORMATION PIPELINE")
        logger.info("=" * 60)
        
        results = {}
        
        # PyTorch Geometric
        pg_transformer = PyTorchGeometricTransformer(self.graph, self.node_features, self.edge_features)
        pg_result = pg_transformer.transform()
        if pg_result:
            results['pytorch_geometric'] = pg_result
            self.transformations['pytorch_geometric'] = pg_result
        
        # DGL
        dgl_transformer = DGLTransformer(self.graph, self.node_features, self.edge_features)
        dgl_result = dgl_transformer.transform()
        if dgl_result:
            results['dgl'] = dgl_result
            self.transformations['dgl'] = dgl_result
        
        # NetworkX
        nx_transformer = NetworkXTransformer(self.graph, self.node_features, self.edge_features)
        nx_result = nx_transformer.transform()
        results['networkx'] = nx_result
        self.transformations['networkx'] = nx_result
        
        logger.info(f"Transformation complete: {len(results)} formats generated")
        return results
    
    def save_pytorch_geometric(self, output_path: str) -> Optional[str]:
        """Save PyTorch Geometric format"""
        if 'pytorch_geometric' not in self.transformations:
            logger.warning("PyTorch Geometric transformation not available")
            return None
        
        try:
            import torch
            data = self.transformations['pytorch_geometric']['data']
            torch.save(data, output_path)
            logger.info(f"Saved PyTorch Geometric: {output_path}")
            return output_path
        except Exception as e:
            logger.error(f"Failed to save PyTorch Geometric: {e}")
            return None
    
    def save_dgl(self, output_path: str) -> Optional[str]:
        """Save DGL format"""
        if 'dgl' not in self.transformations:
            logger.warning("DGL transformation not available")
            return None
        
        try:
            import dgl
            graph = self.transformations['dgl']['graph']
            dgl.save_graphs(output_path, [graph])
            logger.info(f"Saved DGL: {output_path}")
            return output_path
        except Exception as e:
            logger.error(f"Failed to save DGL: {e}")
            return None
    
    def save_networkx(self, output_path: str) -> str:
        """Save NetworkX format"""
        import pickle
        graph = self.transformations['networkx']['graph']
        with open(output_path, 'wb') as f:
            pickle.dump(graph, f)
        logger.info(f"Saved NetworkX: {output_path}")
        return output_path
    
    def save_gexf(self, output_path: str) -> str:
        """Save GEXF format"""
        gexf_transformer = GEXFTransformer(self.graph, self.node_features)
        return gexf_transformer.transform(output_path)
    
    def save_all(self, output_dir: str):
        """Save all transformation formats"""
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Saving all formats to {output_dir}")
        
        # Save statistics
        stats = {
            'num_nodes': self.graph.number_of_nodes(),
            'num_edges': self.graph.number_of_edges(),
            'num_node_features': len(next(iter(self.node_features.values())) if self.node_features else []),
            'transformations': list(self.transformations.keys())
        }
        with open(output_dir / 'stats.json', 'w') as f:
            json.dump(stats, f, indent=2)
        
        # Save individual formats
        self.save_pytorch_geometric(str(output_dir / 'graph.pt'))
        self.save_dgl(str(output_dir / 'graph.dgl'))
        self.save_networkx(str(output_dir / 'graph.gpickle'))
        self.save_gexf(str(output_dir / 'graph.gexf'))
        
        logger.info(f"Saved all formats to {output_dir}")
        
        return output_dir
