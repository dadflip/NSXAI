# NSXAI Stack — IA Neuro-Symbolique

## Architecture

```
Internet
   ↓ (Cloudflare Tunnel)
  Nginx :9000
   ├── /fuseki/    → Fuseki :3030  (Triplestore RDF)
   ├── /hermit/    → HermiT :7777  (Raisonneur OWL DL)
   ├── /api/       → LMS API :4000 (Node.js/Hono)
   ├── /sparql-ui/ → YASGUI :8082  (UI SPARQL)
   └── /vowl/      → WebVOWL :8083 (Visu OWL)
```

## Démarrage

### 1. Préparer les ontologies
```bash
mkdir -p ontologies
cp /chemin/vers/*.owl ontologies/
```

### 2. Configurer le .env
```bash
cp .env .env.local
# Éditer CLOUDFLARE_TOKEN, JWT_SECRET
```

### 3. Lancer le stack
```bash
docker compose up -d
```

### 4. Vérifier
```bash
docker compose ps
docker compose logs hermit   # attendre "HermiT ready"
```

## API HermiT — Endpoints

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | /health | Statut + cohérence |
| GET | /consistent | L'ontologie est-elle cohérente ? |
| GET | /classes | Toutes les classes satisfiables |
| GET | /classes/subclasses?iri=...&direct=false | Sous-classes inférées |
| GET | /classes/superclasses?iri=...&direct=false | Super-classes inférées |
| GET | /instances?iri=...&direct=false | Instances d'une classe |
| GET | /individual/types?iri=... | Types inférés d'un individu |
| GET | /individual/properties?iri=... | Propriétés d'un individu |
| POST | /classify | Classification complète → pousse vers Fuseki |
| POST | /check | Vérifie la cohérence d'un individu |
| POST | /reload | Recharge l'ontologie |

## Exemples

### Vérifier cohérence
```bash
curl http://localhost:7777/consistent
```

### Types inférés d'un joueur
```bash
curl "http://localhost:7777/individual/types?iri=http://surveys.nees.com.br/lms/Player/uuid"
```

### Lancer la classification complète
```bash
curl -X POST http://localhost:7777/classify
# → pousse les inférences dans Fuseki (named graph: .../inferred)
```

### Requête SPARQL sur les inférences
```sparql
SELECT ?player ?type WHERE {
  GRAPH <http://surveys.nees.com.br/lms/inferred> {
    ?player a ?type .
  }
}
```

## Pipeline complet

```
1. LMS API → POST données joueur → Fuseki /GaTO/update
2. POST /hermit/classify → HermiT raisonne sur le graphe
3. Inférences → Fuseki (named graph :inferred)
4. SPARQL sur Fuseki → requêtes riches (inféré + asserté)
5. WebVOWL → visualisation de l'ontologie
6. YASGUI → exploration interactive du graphe peuplé
```

## Accès local

| Service | URL locale |
|---------|-----------|
| Nginx (point d'entrée) | http://localhost:19000 |
| Fuseki | http://localhost:13030 |
| HermiT API | http://localhost:17777 |
| LMS API | http://localhost:14000 |
| YASGUI | http://localhost:18082 |
| WebVOWL | http://localhost:18083 |

## Tunneler vers internet (à la demande)

```bash
# Via Cloudflare (temporaire, sans compte)
cloudflared tunnel --url http://localhost:19000

# Via ngrok
ngrok http 19000
```

Un seul tunnel suffit — nginx route vers tous les services via les sous-chemins.
